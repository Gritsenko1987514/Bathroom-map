//
//  BMAppDelegate.h
//  BathroomMap
//
//  Created by Xin Liang on 1/23/13.
//  Copyright (c) 2013 BLS Web Services. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "CustomTabbar.h"

#import "BMAPI.h"

#import "BMConstants.h"

#import "BMUtility.h"

#import "BMLocation.h"

#define AppDelegate ((BMAppDelegate *)[[UIApplication sharedApplication] delegate])

@class Reachability, BMRootVC, BMMapVC, BMListVC, BMSettingVC, BMNearmeVC, BMViewController;

@interface BMAppDelegate : UIResponder <UIApplicationDelegate, UITabBarControllerDelegate, CustomTabDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) BMRootVC *rootVC;

@property (nonatomic, strong) CustomTabbar *tabbarController;

@property (nonatomic, strong) BMNearmeVC *nearmeVC;
//@property (nonatomic, strong) BMMapVC *nearmeVC;

@property (nonatomic, strong) BMMapVC *mapVC;

@property (nonatomic, strong) BMListVC *listVC;

@property (nonatomic, strong) BMSettingVC *settingVC;

@property (strong, nonatomic) Reachability *reachability;

@property (nonatomic, strong) BMViewController *viewController;

@property (nonatomic, assign) BOOL isOnline;

@property (nonatomic, strong) NSMutableArray *locationArray;    //  array of all locations

@end
