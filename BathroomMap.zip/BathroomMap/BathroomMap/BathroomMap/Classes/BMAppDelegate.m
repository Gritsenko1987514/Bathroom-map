//
//  BMAppDelegate.m
//  BathroomMap
//
//  Created by Xin Liang on 1/23/13.
//  Copyright (c) 2013 BLS Web Services. All rights reserved.
//

#import "BMAppDelegate.h"

#import "BMMapVC.h"

#import "Reachability.h"

#import "BMNavigationBar.h"

#import "BMUtility.h"

#import "BMAPI.h"

#import "BMRootVC.h"

#import "BMListVC.h"

#import "BMNearmeVC.h"

#import "BMSettingVC.h"

#import "BMViewController.h"

@interface BMAppDelegate ()

- (void)changedNetworkConnection:(NSNotification *)notification;

@end

@implementation BMAppDelegate

@synthesize window = _window;
@synthesize rootVC = _rootVC;
@synthesize tabbarController = _tabbarController;
@synthesize reachability = _reachability;
@synthesize isOnline = _isOnline;
@synthesize nearmeVC = _nearmeVC;
@synthesize mapVC = _mapVC;
@synthesize listVC = _listVC;
@synthesize settingVC = _settingVC;
@synthesize locationArray = _locationArray;
@synthesize viewController = _viewController;

- (void)dealloc
{
    [_window release];
    [_tabbarController release];
    [_reachability release];
    [_mapVC release];
    [_listVC release];
    [_rootVC release];
    [_nearmeVC release];
    [_settingVC release];
    [_locationArray release];
    [_viewController release];
    
    [super dealloc];
}

#pragma mark - CustomTabDelegate

- (void)didselectTab:(NSInteger)tabIndex
{
    [_tabbarController selectTab:tabIndex];
}

#pragma mark - Private

- (void)changedNetworkConnection:(NSNotification *)notification
{
    //  called after network status changes
    NetworkStatus internetStatus = [_reachability currentReachabilityStatus];
    switch (internetStatus) {
        case NotReachable:
#ifdef DEBUG
            NSLog(@"The internet is down.");
#endif
            self.isOnline = NO;
            break;
        case ReachableViaWiFi:
#ifdef DEBUG
            NSLog(@"The internet is working via WIFI.");
#endif
            self.isOnline = YES;
            break;
            
        case ReachableViaWWAN:
#ifdef DEBUG
            NSLog(@"The internet is working via WWAN.");
#endif
            self.isOnline = YES;
            break;
            
        default:
            break;
    }
}

#pragma mark - Exception Handler

void exceptionHanler(NSException *exception)
{
    NSLog(@"BathroomMap Error: %@", exception.description);
}

#pragma mark - Application LifeCycle

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    NSSetUncaughtExceptionHandler(&exceptionHanler);
    
    self.window = [[[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]] autorelease];
    
    // Override point for customization after application launch.
    
    //  configure view hirache
//    _tabbarController = [[CustomTabbar alloc] init];
//    _tabbarController.delegate = self;
//    _tabbarController.customDelegate = self;
//    
//    _nearmeVC = [[BMNearmeVC alloc] initWithNibName:@"BMNearmeVC" bundle:nil];
//    UINavigationController *nearmeNavigationController = [BMNavigationBar navigationControllerWithRootViewController:_nearmeVC];
//    
//    _mapVC = [[BMMapVC alloc] initWithNibName:@"BMMapVC"
//                                       bundle:nil];
//    UINavigationController *mapNavigationController = [BMNavigationBar navigationControllerWithRootViewController:_mapVC];
//    
//    _listVC = [[BMListVC alloc] initWithNibName:@"BMListVC"
//                                         bundle:nil];
//    UINavigationController *listNavigationController = [BMNavigationBar navigationControllerWithRootViewController:_listVC];
//    
//    _settingVC = [[BMSettingVC alloc] initWithNibName:@"BMSettingVC"
//                                               bundle:nil];
//    UINavigationController *settingNavigationController = [BMNavigationBar navigationControllerWithRootViewController:_settingVC];
//    
//    _tabbarController.viewControllers = [NSArray arrayWithObjects:nearmeNavigationController,
//                                         mapNavigationController,
//                                         listNavigationController,
//                                         settingNavigationController,
//                                         nil];
//    _rootVC = [[BMRootVC alloc] initWithNibName:@"BMRootVC" bundle:nil];
//    [_rootVC addContentViewController:_tabbarController];
    _viewController = [[BMViewController alloc] initWithNibName:@"BMViewController" bundle:nil];
    
    //  set up reachability
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(changedNetworkConnection:)
                                                 name:kReachabilityChangedNotification
                                               object:nil];
    self.reachability = [Reachability reachabilityForInternetConnection];
    [_reachability startNotifier];
    NetworkStatus internetStatus = [_reachability currentReachabilityStatus];
    switch (internetStatus) {
        case NotReachable:
#ifdef DEBUG
            NSLog(@"The internet is down.");
#endif
            self.isOnline = NO;
            
            break;
        case ReachableViaWiFi:
#ifdef DEBUG
            NSLog(@"The internet is working via WIFI.");
#endif
            _isOnline = YES;
            
            break;
            
        case ReachableViaWWAN:
#ifdef DEBUG
            NSLog(@"The internet is working via WWAN.");
#endif
            _isOnline = YES;
            
            break;
            
        default:
            break;
    }
    
    self.window.rootViewController = _viewController;
    [self.window makeKeyAndVisible];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    [userDefault setObject:[NSNumber numberWithFloat:0.0] forKey:kCurrentLat];
    [userDefault setObject:[NSNumber numberWithFloat:0.0] forKey:kCurrentLon];
    
    [userDefault synchronize];
    
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
