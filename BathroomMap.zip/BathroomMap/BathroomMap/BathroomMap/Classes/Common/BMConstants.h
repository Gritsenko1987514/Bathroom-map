//
//  BMConstants.h
//  BM
//
//  Created by Xin Liang on 4/13/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#ifndef BM_BMConstants_h
#define BM_BMConstants_h


#pragma mark - System Versioning Preprocessor Macros

#define SYSTEM_VERSION_EQUAL_TO(v)                  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedSame)
#define SYSTEM_VERSION_GREATER_THAN(v)              ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedDescending)
#define SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(v)  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN(v)                 ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN_OR_EQUAL_TO(v)     ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedDescending)
#define IS_IPHONE                                   ( [[[UIDevice currentDevice] model] isEqualToString:@"iPhone"] )
#define IS_IPOD                                     ( [[[UIDevice currentDevice ] model] isEqualToString:@"iPod touch"] )
#define IS_HEIGHT_GTE_568                           [[UIScreen mainScreen ] bounds].size.height >= 568.0f
#define IS_IPHONE_5                                 ( IS_IPHONE && IS_HEIGHT_GTE_568 )

typedef enum _LocationCategory {
    LocationCategoryAirport = 1,
    LocationCategoryTrainStation,
    LocationCategoryCoffeehouse,
    LocationCategoryHotel,
    LocationCategoryResort,
    LocationCategoryMovieTheater,
    LocationCategoryDepartmentStore,
    LocationCategoryFurnitureStore,
    LocationCategoryBookStore,
    LocationCategoryGroceryStore,
    LocationCategoryRestaurant,
    LocationCategoryTacoTime
} LocationCategory;

typedef enum _RateType {
    RateTypeGood = 3,
    RateTypeNormal = 2,
    RateTypeBad = 1
} RateType;

#pragma mark - Key Constants

#define kKeyUsername    @"Username"
#define kKeyPassword    @"Password"

#pragma mark - Notification Constants

#define kNotificationDidFinishLoadingLandingPage    @"DidFinishLoadingLandingPage"
#define kNotificationDidFailLoadingLandingPage      @"DidFailLoadingLandingPage"
#define kNotificationDidFinishUpdate                @"DidFinishUpdate"
#define kNotificationDidUpdateCurrentLocation       @"DidUpdateCurrentLocation"

#pragma mark - String Constants

#define kStringOn           @"ON"

#define kStringRestaurant   @"Restaurant"
#define kStringHotel        @"Hotel"
#define kStringGasStation   @"Gas Station"
#define kStringParkingArea  @"Parking Area"
#define kStringCoffee       @"Coffeehouse"
#define kStringAirplane     @"Airport"
#define kStringCampsite     @"Camp Site"
#define kStringBookStore    @"Bookstore"
#define kStringDepartment   @"Department Store"
#define kStringFurniture    @"Furniture Store"
#define kStringGrocery      @"Grocery Store"
#define kStringMovieTheater @"Movie Theater"
#define kStringResort       @"Resort"
#define kStringTacoTime     @"Taco Time"
#define kStringTrainStation @"Train Station"

#define kStringId           @"id"
#define kStringCategory     @"category"
#define kStringLatitude     @"geo_lat"
#define kStringLongitude    @"geo_long"
#define kStringPhone        @"phone"
#define kStringDescription  @"description"
#define kStringState        @"state"
#define kStringCreatedAt    @"created_at"
#define kStringStreet       @"street"
#define kStringZipcode      @"zipcode"
#define kStringCity         @"city"
#define kStringUpdatedAt    @"updated_at"
#define kStringFeedbacks    @"feedbacks"
#define kStringWebsite      @"website"
#define kStringName         @"name"
#define kStringRating       @"rating"
#define kStringFeedback     @"feedback"
#define kStringLocationId   @"location_id"
#define kStringPublish      @"publish"
#define kStringUser         @"user"
#define kStringEmail        @"email"

#define kFirstName          @"FirstName"
#define kLastName           @"LastName"
#define kEmailAddress       @"EmailAddress"
#define kUserName           @"UserName"

#define kCurrentLat         @"CurrentLatitude"
#define kCurrentLon         @"CurrentLongitude"

#pragma mark - Integer Constants

#define kIntLargeFontSize   22

#define kMaxDistance        0.4

#endif
