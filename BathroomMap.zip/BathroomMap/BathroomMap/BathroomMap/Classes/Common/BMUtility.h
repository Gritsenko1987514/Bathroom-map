//
//  BMUtility.h
//  BM
//
//  Created by Xin Liang on 4/13/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MBProgressHUD.h"
#import <CoreLocation/CoreLocation.h>

@interface BMUtility : NSObject <MBProgressHUDDelegate>

#pragma mark - LifeCycle

+ (BMUtility *) sharedInstance;

+ (void) destroyInstance;

- (void)showLoading:(UIView *)view
       withAnimated:(BOOL)animated
              label:(NSString *)label;

- (void)hideLoading:(UIView *)view
       withAnimated:(BOOL)animated;

- (void)showConfirm:(UIView *)view
          withLabel:(NSString *)label;

#pragma mark - NSDate

- (NSString *)userVisibleDateTimeStringForRFC3339DateTimeString:(NSString *)rfc3339DateTimeString;

- (NSDate *)dateTimeForREC3339DateTimeString:(NSString *)rfc3339DateTimeString;

- (NSString *)userVisibleMonthStringForRFC3339DateTimeString:(NSString *)rfc3339DateTimeString;

- (NSString *)userVisibleDayStringForRFC3339DateTimeString:(NSString *)rfc3339DateTimeString;

+ (NSString *)stringWithDate:(NSDate *)date;

+ (NSString *)stringWithSeconds:(NSInteger)time_in_seconds;

#pragma mark - UI

+ (CGSize)sizeOfString:(NSString *)string
    andConstrainedSize:(CGSize)constrainedSize;

+ (CGSize)sizeOfString:(NSString *)string
    andConstrainedSize:(CGSize)constrainedSize
           andFontSize:(float)fontSize;

+ (NSInteger)widthOfString:(NSString *)string
                 andHeight:(NSInteger)height
                   andFont:(NSInteger)font;

#pragma mark - Math

+ (NSInteger)isInteger:(float)value;

+ (BOOL)isNumber:(NSString *)value;

+ (NSString *)stringFromInteger:(NSInteger)value;

+ (NSString *)stringFromFloat:(float)value;

+ (CGFloat)calculateDistanceBetweenSource:(CLLocationCoordinate2D)sourceCoords destination:(CLLocationCoordinate2D)destinationCoords;

#pragma mark - Prefereneces

@end
