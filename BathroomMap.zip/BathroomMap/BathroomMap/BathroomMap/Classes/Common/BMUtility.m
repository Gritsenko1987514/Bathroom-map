//
//  BMUtility.m
//  BM
//
//  Created by Xin Liang on 4/13/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "BMUtility.h"
#import "BMConstants.h"
#import "DimView.h"
#import "BMBaseVC.h"

static BMUtility *instance;

@implementation BMUtility


#pragma mark - LifeCycle

+ (BMUtility *) sharedInstance {
	@synchronized ([BMUtility class])
	{
		if (!instance) {
			instance = [[BMUtility alloc] init];
		}
		return instance;
	}
}

+ (void) destroyInstance {
	@synchronized ([BMUtility class])
	{
        if (instance)
        {
            [instance release];
            instance = nil;            
        }
        
	}
}

- (void)showLoading:(UIView *)view withAnimated:(BOOL)animated label:(NSString *)label
{
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:view animated:animated];
    hud.dimBackground = YES;
    hud.labelText = label;
}

- (void)hideLoading:(UIView *)view withAnimated:(BOOL)animated
{
    [MBProgressHUD hideHUDForView:view animated:animated];
}

- (void)showConfirm:(UIView *)view withLabel:(NSString *)label
{
    MBProgressHUD *HUD = [[MBProgressHUD alloc] initWithView:view];
	[view addSubview:HUD];
	
	// The sample image is based on the work by http://www.pixelpressicons.com, http://creativecommons.org/licenses/by/2.5/ca/
	// Make the customViews 37 by 37 pixels for best results (those are the bounds of the build-in progress indicators)
	HUD.customView = [[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"37x-Checkmark.png"]] autorelease];
	
	// Set custom view mode
	HUD.mode = MBProgressHUDModeCustomView;
	
	HUD.delegate = self;
	HUD.labelText = label;
	
	[HUD show:YES];
	[HUD hide:YES afterDelay:1.5];
}


#pragma mark -
#pragma mark MBProgressHUDDelegate methods

- (void)hudWasHidden:(MBProgressHUD *)hud {
	// Remove HUD from screen when the HUD was hidded
	[hud removeFromSuperview];
	[hud release];
	hud = nil;
}

#pragma mark - Date Related Utility

- (NSString *)userVisibleDateTimeStringForRFC3339DateTimeString:(NSString *)rfc3339DateTimeString
// Returns a user-visible date time string that corresponds to the 
// specified RFC 3339 date time string. Note that this does not handle 
// all possible RFC 3339 date time strings, just one of the most common 
// styles.
{
    NSString *          userVisibleDateTimeString;
    NSDateFormatter *   rfc3339DateFormatter;
    NSLocale *          enUSPOSIXLocale;
    NSDate *            date;
    NSDateFormatter *   userVisibleDateFormatter;
    
    userVisibleDateTimeString = nil;
    
    // Convert the RFC 3339 date time string to an NSDate.
    
    rfc3339DateFormatter = [[[NSDateFormatter alloc] init] autorelease];
    assert(rfc3339DateFormatter != nil);
    
    enUSPOSIXLocale = [[[NSLocale alloc] initWithLocaleIdentifier:@"en_US_POSIX"] autorelease];
    assert(enUSPOSIXLocale != nil);
    
    [rfc3339DateFormatter setLocale:enUSPOSIXLocale];
    [rfc3339DateFormatter setDateFormat:@"yyyy'-'MM'-'dd'T'HH':'mm':'ss'Z'"];
    [rfc3339DateFormatter setTimeZone:[NSTimeZone timeZoneForSecondsFromGMT:0]];
    
    date = [rfc3339DateFormatter dateFromString:rfc3339DateTimeString];
    if (date != nil) {
        
        // Convert the NSDate to a user-visible date string.
        
        userVisibleDateFormatter = [[[NSDateFormatter alloc] init] autorelease];
        assert(userVisibleDateFormatter != nil);
        
        [userVisibleDateFormatter setDateFormat:@"MMM d, yyyy"];
        
        userVisibleDateTimeString = [userVisibleDateFormatter stringFromDate:date];
    }
    return userVisibleDateTimeString;
}

- (NSString *)userVisibleMonthStringForRFC3339DateTimeString:(NSString *)rfc3339DateTimeString
// Returns a user-visible date time string that corresponds to the 
// specified RFC 3339 date time string. Note that this does not handle 
// all possible RFC 3339 date time strings, just one of the most common 
// styles.
{
    NSString *          userVisibleDateTimeString;
    NSDateFormatter *   rfc3339DateFormatter;
    NSLocale *          enUSPOSIXLocale;
    NSDate *            date;
    NSDateFormatter *   userVisibleDateFormatter;
    
    userVisibleDateTimeString = nil;
    
    // Convert the RFC 3339 date time string to an NSDate.
    
    rfc3339DateFormatter = [[[NSDateFormatter alloc] init] autorelease];
    assert(rfc3339DateFormatter != nil);
    
    enUSPOSIXLocale = [[[NSLocale alloc] initWithLocaleIdentifier:@"en_US_POSIX"] autorelease];
    assert(enUSPOSIXLocale != nil);
    
    [rfc3339DateFormatter setLocale:enUSPOSIXLocale];
    [rfc3339DateFormatter setDateFormat:@"yyyy'-'MM'-'dd'T'HH':'mm':'ss'Z'"];
    [rfc3339DateFormatter setTimeZone:[NSTimeZone timeZoneForSecondsFromGMT:0]];
    
    date = [rfc3339DateFormatter dateFromString:rfc3339DateTimeString];
    if (date != nil) {
        
        // Convert the NSDate to a user-visible date string.
        
        userVisibleDateFormatter = [[[NSDateFormatter alloc] init] autorelease];
        assert(userVisibleDateFormatter != nil);
        
        [userVisibleDateFormatter setDateFormat:@"MMM"];
        
        userVisibleDateTimeString = [userVisibleDateFormatter stringFromDate:date];
    }
    return userVisibleDateTimeString;
}

- (NSString *)userVisibleDayStringForRFC3339DateTimeString:(NSString *)rfc3339DateTimeString
// Returns a user-visible date time string that corresponds to the 
// specified RFC 3339 date time string. Note that this does not handle 
// all possible RFC 3339 date time strings, just one of the most common 
// styles.
{
    NSString *          userVisibleDateTimeString;
    NSDateFormatter *   rfc3339DateFormatter;
    NSLocale *          enUSPOSIXLocale;
    NSDate *            date;
    NSDateFormatter *   userVisibleDateFormatter;
    
    userVisibleDateTimeString = nil;
    
    // Convert the RFC 3339 date time string to an NSDate.
    
    rfc3339DateFormatter = [[[NSDateFormatter alloc] init] autorelease];
    assert(rfc3339DateFormatter != nil);
    
    enUSPOSIXLocale = [[[NSLocale alloc] initWithLocaleIdentifier:@"en_US_POSIX"] autorelease];
    assert(enUSPOSIXLocale != nil);
    
    [rfc3339DateFormatter setLocale:enUSPOSIXLocale];
    [rfc3339DateFormatter setDateFormat:@"yyyy'-'MM'-'dd'T'HH':'mm':'ss'Z'"];
    [rfc3339DateFormatter setTimeZone:[NSTimeZone timeZoneForSecondsFromGMT:0]];
    
    date = [rfc3339DateFormatter dateFromString:rfc3339DateTimeString];
    if (date != nil) {
        
        // Convert the NSDate to a user-visible date string.
        
        userVisibleDateFormatter = [[[NSDateFormatter alloc] init] autorelease];
        assert(userVisibleDateFormatter != nil);
        
        [userVisibleDateFormatter setDateFormat:@"d"];
        
        userVisibleDateTimeString = [userVisibleDateFormatter stringFromDate:date];
    }
    return userVisibleDateTimeString;
}

- (NSDate *)dateTimeForREC3339DateTimeString:(NSString *)rfc3339DateTimeString
{
    NSString *          userVisibleDateTimeString;
    NSDateFormatter *   rfc3339DateFormatter;
    NSLocale *          enUSPOSIXLocale;
    NSDate *            date;
    
    userVisibleDateTimeString = nil;
    
    // Convert the RFC 3339 date time string to an NSDate.
    
    rfc3339DateFormatter = [[[NSDateFormatter alloc] init] autorelease];
    assert(rfc3339DateFormatter != nil);
    
    enUSPOSIXLocale = [[[NSLocale alloc] initWithLocaleIdentifier:@"en_US_POSIX"] autorelease];
    assert(enUSPOSIXLocale != nil);
    
    [rfc3339DateFormatter setLocale:enUSPOSIXLocale];
    [rfc3339DateFormatter setDateFormat:@"yyyy'-'MM'-'dd'T'HH':'mm':'ss'Z'"];
    [rfc3339DateFormatter setTimeZone:[NSTimeZone timeZoneForSecondsFromGMT:0]];
    
    date = [rfc3339DateFormatter dateFromString:rfc3339DateTimeString];
    
    return date;
}

+ (NSString *)stringWithDate:(NSDate *)date
{
    if (!date)
    {
        return nil;
    }
    
    NSDateFormatter *formatter = [[[NSDateFormatter alloc] init] autorelease];
    [formatter setDateFormat:@"MMMM dd, yyyy"];
    return [formatter stringFromDate:date];
}

//  return duration time string from seconds
+ (NSString *)stringWithSeconds:(NSInteger)time_in_seconds
{
    NSInteger hours = time_in_seconds / 3600;
    NSInteger minutes = ((NSInteger)time_in_seconds % 3600) / 60;
    NSInteger seconds = (time_in_seconds - hours * 3600 - minutes * 60);
    
    hours = abs(hours);
    minutes = abs(minutes);
    seconds = abs(seconds);
    
    NSString *sinceTimeString = nil;
    
    if (hours > 0)
    {
        //  hours exist
        if (hours > 1)
            sinceTimeString = [NSString stringWithFormat:@"%d h %d m %d s", hours, minutes, seconds];
        else
            sinceTimeString = [NSString stringWithFormat:@"%d h %d m %d s", hours, minutes, seconds];
        
    }
    else
    {
        //  hours not exist
        if (minutes > 0)
        {
            //  minutes exist
            if (minutes > 1)
                sinceTimeString = [NSString stringWithFormat:@"%d m %d s", minutes, seconds];
            else
                sinceTimeString = [NSString stringWithFormat:@"%d m %d s", minutes, seconds];
        }
        else
        {
            //  minutes not exist
            if (seconds > 1)
                sinceTimeString = [NSString stringWithFormat:@"%d s", seconds];
            else
                sinceTimeString = [NSString stringWithFormat:@"%d s", seconds];
        }
    }
    
    return sinceTimeString;
}
#pragma mark - UI

+ (NSInteger)widthOfString:(NSString *)string
                 andHeight:(NSInteger)height
                   andFont:(NSInteger)font
{
    CGSize size;
    
    CGSize constrainedSize = CGSizeMake(CGFLOAT_MAX, height);
    
    size = [string sizeWithFont:[UIFont fontWithName:@"Thonburi-Bold"
                                                size:font]
              constrainedToSize:constrainedSize
                  lineBreakMode:NSLineBreakByWordWrapping];
    
    return size.width;
}

+ (CGSize)sizeOfString:(NSString *)string
    andConstrainedSize:(CGSize)constrainedSize
{
    CGSize size;
    
    size = [string sizeWithFont:[UIFont fontWithName:@"Thonburi-Bold"
                                                size:18]
              constrainedToSize:constrainedSize
                  lineBreakMode:NSLineBreakByCharWrapping];
    
    return size;
}

+ (CGSize)sizeOfString:(NSString *)string
    andConstrainedSize:(CGSize)constrainedSize
           andFontSize:(float)fontSize
{
    CGSize size;
    
    size = [string sizeWithFont:[UIFont systemFontOfSize:fontSize]
              constrainedToSize:constrainedSize
                  lineBreakMode:NSLineBreakByCharWrapping];
    
    return size;
}

//  show loading gif image animated with dim background view
+ (void)showLoading:(UIView *)view
{
    //  display diming background view behind the loading gif iamge view animated
    DimView *dimView = [[[DimView alloc] initWithFrame:view.bounds] autorelease];
    dimView.backgroundColor = [UIColor clearColor];
    dimView.tag = kIntLoadingViewTag;
    
    UIImage *frameImage = [UIImage imageNamed:@"frame1"];
    NSInteger width = frameImage.size.width;
    NSInteger height = frameImage.size.height;
    
    CGRect rect;
    rect = view.bounds;
    rect.origin.x = (rect.size.width - width) / 2;
    rect.origin.y = (rect.size.height - height) / 2;
    rect.size.width = width;
    rect.size.height = height;
    UIImageView* animatedImageView = [[[UIImageView alloc] initWithFrame:rect] autorelease];
    animatedImageView.animationImages = [NSArray arrayWithObjects:
                                         [UIImage imageNamed:@"frame10"],
                                         [UIImage imageNamed:@"frame1"],
                                         [UIImage imageNamed:@"frame2"],
                                         [UIImage imageNamed:@"frame3"],
                                         [UIImage imageNamed:@"frame4"],
                                         [UIImage imageNamed:@"frame5"],
                                         [UIImage imageNamed:@"frame6"],
                                         [UIImage imageNamed:@"frame7"],
                                         [UIImage imageNamed:@"frame8"],
                                         [UIImage imageNamed:@"frame9"],
                                         nil];
    animatedImageView.animationDuration = 1.5f;
    animatedImageView.animationRepeatCount = 1000;
    [animatedImageView startAnimating];
    [dimView addSubview: animatedImageView];
    [view addSubview:dimView];
}

//  hide loading view from this view
+ (void)hideLoading:(UIView *)view
{
    UIView *loadingView = [view viewWithTag:kIntLoadingViewTag];
    [loadingView removeFromSuperview];
}

#pragma mark - Math

//  retun integer value of that float value if given float value is integer or not
//  else, return -1
+ (NSInteger)isInteger:(float)value
{
    NSScanner *scan = [NSScanner scannerWithString:[NSString stringWithFormat:@"%f", value]];

    NSInteger integerValue = 0;
    [scan scanInteger:&integerValue];
    float temp = value - integerValue;
    if (temp == 0)
    {
        //  this float value is integer type
        return integerValue;
    }
    else
    {
        //   this float value is float type
        return -1;
    }
}

//  check if given string value is number type or not
+ (BOOL)isNumber:(NSString *)value
{
    NSScanner *scan = [NSScanner scannerWithString:value];

    if (![scan scanFloat:NULL] || ![scan isAtEnd])
        return NO;
    else
        return YES;
}

//  return representation String from integer (if the value exceed 6 digits, float point representation string)
+ (NSString *)stringFromInteger:(NSInteger)value
{
    NSString *stringValue = nil;
    
    stringValue = [NSString stringWithFormat:@"%.4G", (float)value];
    
    return stringValue;
}

//  return representation String from float (if the value exceed 6 digits, float point representation string)
+ (NSString *)stringFromFloat:(float)value
{
    NSString *stringValue = nil;
    
    if (isnan(value))
        return @"";

    stringValue = [NSString stringWithFormat:@"%.4G", value];

    return stringValue;
}

+ (CGFloat)calculateDistanceBetweenSource:(CLLocationCoordinate2D)sourceCoords destination:(CLLocationCoordinate2D)destinationCoords
{
    // this radius is in KM => if miles are needed it is calculated during setter of Place.distance
    
    double nRadius = 6371;
    
    // Get the difference between our two points
    
    // then convert the difference into radians
    
    double nDLat = (sourceCoords.latitude - destinationCoords.latitude) * (M_PI / 180);
    double nDLon = (sourceCoords.longitude - destinationCoords.longitude) * (M_PI / 180);
    
    double nLat1 = destinationCoords.latitude * (M_PI / 180);
    double nLat2 = destinationCoords.latitude * (M_PI / 180);
    
    double nA = pow (sin(nDLat/2), 2) + cos(nLat1) * cos(nLat2) * pow(sin(nDLon / 2), 2);
    
    double nC = 2 * atan2(sqrt(nA), sqrt(1 - nA));
    
    double nD = nRadius * nC;
    
    //NSLog(@"Distance is %f",nD);
    
    return nD; // converts to miles or not (if en_) => implicit in method
}

#pragma mark - Preferences

@end
