//
//  RemoteImageView.h
//  BLS Web Servcies
//
//  Created by Xin Liang on 7/21/10.
//  Copyright 2010 BLS Web Services. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DownloadResizeRequest.h"

@interface RemoteImageView : UIImageView
{
	UIActivityIndicatorView *activityView;

	BOOL thumbMode;
	ASIHTTPRequest *currentRequest;
}

@property (readwrite) BOOL thumbMode;
@property (nonatomic) BOOL isSmallActivity;

- (void)setURL:(NSURL *)newURL;

@end
