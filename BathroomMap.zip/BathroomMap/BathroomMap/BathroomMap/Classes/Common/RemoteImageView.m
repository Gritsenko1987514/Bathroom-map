//
//  RemoteImageView.m
//  BLS Web Services
//
//  Created by Xin Liang on 7/21/10.
//  Copyright 2010 BLS Web Services. All rights reserved.
//

#import "RemoteImageView.h"
#import "BMQueueHandler.h"

@implementation RemoteImageView

@synthesize thumbMode;
@synthesize isSmallActivity = _isSmallActivity;

- (id)initWithFrame:(CGRect)frame
{
	if (self = [super initWithFrame:frame])
	{
		currentRequest = nil;
	}
	return self;
}

- (void)setImagePath:(NSString *)inPath
{
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	[self setImage:[UIImage imageWithContentsOfFile:inPath]];
	[pool release];
}

- (void)setURL:(NSURL *)inURL
{
#ifdef DEBUG
//        NSLog(@"Here: %@ %@ %@", inURL, currentRequest, (currentRequest ? [currentRequest url] : @""));
//        NSLog(@"remote image url: %@", inURL);
#endif
    
	@synchronized (self)
	{
		if (currentRequest)
		{
			//if ([[currentRequest url] isEqual:inURL])
			//	return;

			[currentRequest setDelegate:nil];
			[currentRequest cancel];
			//[currentRequest setQueuePriority:NSOperationQueuePriorityLow];
			currentRequest = nil;
		}
	}

	if (inURL == nil)
	{
		[self setImage:nil];
		if (activityView)
		{
			[activityView removeFromSuperview];
			activityView = nil;
		}
		return;
	}
	[self setImage:nil];

	NSString *tmpFilename = [[[inURL absoluteString] componentsSeparatedByCharactersInSet:[NSCharacterSet punctuationCharacterSet]] componentsJoinedByString:@"_"];

	//DLog(@"%@ %d", [NSTemporaryDirectory() stringByAppendingPathComponent:tmpFilename], [[NSFileManager defaultManager] fileExistsAtPath:[NSTemporaryDirectory() stringByAppendingPathComponent:tmpFilename]]);
	//[[NSFileManager defaultManager] removeItemAtPath:[NSTemporaryDirectory() stringByAppendingPathComponent:tmpFilename] error:nil];
	if ([[NSFileManager defaultManager] fileExistsAtPath:[NSTemporaryDirectory() stringByAppendingPathComponent: tmpFilename]] && (!thumbMode || [[NSFileManager defaultManager] fileExistsAtPath:[NSTemporaryDirectory() stringByAppendingPathComponent:[@"thumb_" stringByAppendingString:tmpFilename]]]))
	{
		if (activityView)
		{
			[activityView removeFromSuperview];
			activityView = nil;
		}

		if (!thumbMode) {
            
#ifdef DEBUG
//            NSLog(@"image file path = %@", [NSTemporaryDirectory() stringByAppendingPathComponent:tmpFilename]);
#endif
            
            UIImage *fullImage = [UIImage imageWithContentsOfFile:[NSTemporaryDirectory() stringByAppendingPathComponent:tmpFilename]];

			[self setImage:fullImage];
            
        } else {
            
#ifdef DEBUG
//            NSLog(@"image file path = %@", [NSTemporaryDirectory() stringByAppendingPathComponent:[@"thumb_" stringByAppendingString:tmpFilename]]);
#endif
            
            UIImage *thumbImage = [UIImage imageWithContentsOfFile:[NSTemporaryDirectory() stringByAppendingPathComponent:[@"thumb_" stringByAppendingString:tmpFilename]]];
            
			[self setImage:thumbImage];
        }

	}
	else
	{
		if (!activityView)
		{
            activityView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:_isSmallActivity?UIActivityIndicatorViewStyleGray:UIActivityIndicatorViewStyleGray];
			[activityView setCenter:CGPointMake(self.frame.size.width / 2.0f, self.frame.size.height / 2.0f)];
#ifdef DEBUG
//            NSLog(@"=========position of activity view:=============\n %f, %f", activityView.center.x, activityView.center.y);
#endif
			[self addSubview:activityView];
			[activityView release];

			[activityView startAnimating];
		}

		@synchronized (self)
		{
			if (!thumbMode)
				currentRequest = [ASIHTTPRequest requestWithURL:inURL];
			else
			{
				CGSize maxSize = self.frame.size;
				if ([[UIScreen mainScreen] respondsToSelector:@selector(scale)])
				{
					maxSize.width *= [[UIScreen mainScreen] scale];
					maxSize.height *= [[UIScreen mainScreen] scale];
				}

				currentRequest = [DownloadResizeRequest requestWithURL:inURL];
				[(DownloadResizeRequest *)currentRequest setThumbDestinationPath:[NSTemporaryDirectory() stringByAppendingPathComponent:[@"thumb_" stringByAppendingString:tmpFilename]]];
#ifdef DEBUG
//                NSLog(@"will saved path = %@", [NSTemporaryDirectory() stringByAppendingPathComponent:[@"thumb_" stringByAppendingString:tmpFilename]]);
#endif
				[(DownloadResizeRequest *)currentRequest setMaxSize:maxSize];
			}
			[currentRequest setDownloadDestinationPath:[NSTemporaryDirectory() stringByAppendingPathComponent:tmpFilename]];
            [currentRequest setDelegate:self];
            /*
            [currentRequest setUsername:USER_NAME];
            [currentRequest setPassword:PASSWORD];
             */
            currentRequest.timeOutSeconds = 100;
			[currentRequest setDidFinishSelector:@selector(imageDidFinish:)];
			[currentRequest setDidFailSelector:@selector(imageDidFail:)];
			//[currentRequest setQueuePriority:NSOperationQueuePriorityVeryHigh];
			[[BMQueueHandler imageDownloadQueue] addOperation:currentRequest];
		}
	}
}

#pragma mark ASIHTTPRequest delegate functions
- (void)imageDidFinish:(ASIHTTPRequest *)inRequest
{
#ifdef DEBUG
//    NSLog(@"Success: %@ - %@", [inRequest url], [[inRequest error] localizedDescription]);
#endif
	@synchronized (self)
	{
		if (inRequest == currentRequest)
		{
			UIImage *cellImage;
			if (!thumbMode)
				cellImage = [UIImage imageWithContentsOfFile:[(DownloadResizeRequest *) inRequest downloadDestinationPath]];
			else
				cellImage = [UIImage imageWithContentsOfFile:[(DownloadResizeRequest *)inRequest thumbDestinationPath]];

			[self setImage:cellImage];
//			[self performSelectorOnMainThread:@selector(setNeedsDisplay) withObject:nil waitUntilDone:YES];

			[activityView removeFromSuperview];
			activityView = nil;

			currentRequest = nil;
		}
	}
}

- (void)imageDidFail:(ASIHTTPRequest *)inRequest
{
#ifdef DEBUG
//    NSLog(@"Failed: %@ - %@", [inRequest url], [[inRequest error] localizedDescription]);
#endif
	@synchronized (self)
	{
		if (inRequest == currentRequest)
		{
			[activityView removeFromSuperview];
			activityView = nil;

			currentRequest = nil;
		}
	}
}

- (void)dealloc
{
	@synchronized (self)
	{
		if (currentRequest)
		{
			[currentRequest setDelegate:nil];
			//[currentRequest setQueuePriority:NSOperationQueuePriorityLow];
			currentRequest = nil;
		}
	}
    [super dealloc];
}

@end
