//
//  UIImageExtensions.h
//  BM
//
//  Created by Xin Liang on 4/29/12.
//  Copyright 2012 BLS Web Services. All rights reserved.
//


#import <Foundation/Foundation.h>

@interface UIImage (Resize)

- (UIImage *)resizedImageWithContentMode:(UIViewContentMode)contentMode bounds:(CGSize)bounds interpolationQuality:(CGInterpolationQuality)quality;

- (UIImage *)resizedImageWithSize:(CGSize)newSize;

@end
