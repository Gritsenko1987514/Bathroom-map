//
//  SABaseVC.h
//  CardLust
//
//  Created by System Administrator on 8/5/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BMAPI.h"
#import "BMAppDelegate.h"
#import "BMConstants.h"
#import "BMUtility.h"
#import "APIResponseModel.h"

#define kIntLeftItemTag     101
#define kIntRightItemTag    102
#define kIntTitleTag        100
#define kIntLoadingViewTag  108
#define kIntSearchField     109
#define kIntSearchButton    110

@interface BMBaseVC : UIViewController
{
    NSString *searchKey;
    NSMutableArray *searchLocationArray;
}

- (void)showLeftButtonWithImage:(NSString *)imageName
                     andOverlay:(NSString *)overlayImageName
                    andSelector:(SEL)selector;

- (void)showLeftButtonWithImage:(NSString *)imageName
             andHighlighedImage:(NSString *)secondImageName
                    andSelector:(SEL)selector;

- (void)showLeftButtonWithTitle:(NSString*)title andSelector:(SEL)selector;

- (void)hideLeftButton;

- (NSInteger)showRightButtonWithImage:(NSString *)imageName
                          andSelector:(SEL)selector;

- (void)showRightButtonWithImage:(NSString *)imageName
              andSecondImageName:(NSString *)secondImageName
                     andSelector:(SEL)selector;

- (void)hideRightButton;

- (void)showTitleBar;

- (void)hideTitleBar;

- (void)showInfoButton;

- (void)hideInfoButton;

- (void)showTitle:(NSString *)title;

- (void)hideTitle;

- (void)showRightItem:(NSString *)imageName;

- (void)hideRightItem;

- (void)resetNavigationBar;

- (void)showLoading;

- (void)hideLoading;

- (UITextField*)showTextField:(id <UITextFieldDelegate>)delegate
          andSelector:(SEL)selector;

- (void)showLeftButtonWithImage:(NSString *)imageName
                    andSelector:(SEL)selector;

@end
