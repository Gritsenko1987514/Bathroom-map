//
//  SABaseVC.m
//  CardLust
//
//  Created by System Administrator on 8/5/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "BMBaseVC.h"
#import "BMAppDelegate.h"
#import "BMConstants.h"
#import "BMUtility.h"
#import "BMNavigationBar.h"
#import "DimView.h"
#import "RemoteImageView.h"
#import <QuartzCore/QuartzCore.h>

@implementation BMBaseVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - Action

- (void)onInfo
{
    UINavigationController *navigationController = [BMNavigationBar navigationControllerWithRootViewController:nil];
    navigationController.modalTransitionStyle = UIModalTransitionStyleFlipHorizontal;
    [self.navigationController presentViewController:navigationController animated:YES completion:^{
        
    }];
}

- (void)onRightButton
{
    [self.navigationController pushViewController:nil animated:YES];
}

- (void)onLeftButton
{
    [self.navigationController popViewControllerAnimated:YES];
}

//  @summary: add search field in the navigation bar
- (UITextField*)showTextField:(id <UITextFieldDelegate>)delegate
          andSelector:(SEL)selector
{
    UIView *leftItemContainer = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, 250, 44)] autorelease];
    
    //  add search field to container
    UITextField *searchField = [[[UITextField alloc] initWithFrame:CGRectMake(2, 5, 150, 27)] autorelease];
    searchField.tag = kIntSearchField;
    searchField.delegate = delegate;
    [searchField setBorderStyle:UITextBorderStyleNone];
    [searchField setFont:[UIFont boldSystemFontOfSize:13]];
    searchField.textColor = [UIColor darkGrayColor];
    searchField.background = [UIImage imageNamed:@"SearchTextField"];
    searchField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    searchField.clearButtonMode = UITextFieldViewModeAlways;
    searchField.leftView = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, 10, 20)] autorelease];
    searchField.leftViewMode = UITextFieldViewModeAlways;
    searchField.rightView = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, 10, 20)] autorelease];
    searchField.rightViewMode = UITextFieldViewModeAlways;
    searchField.returnKeyType = UIReturnKeySearch;
    [leftItemContainer addSubview:searchField];
    
    //  add search button to container
    UIButton *searchButton = [UIButton buttonWithType:UIButtonTypeCustom];
    CGRect rect = CGRectMake(157, 5, 80, 27);
    searchButton.frame = rect;
    searchButton.tag = kIntSearchButton;
    [searchButton setBackgroundImage:[UIImage imageNamed:@"SearchButton"]
                            forState:UIControlStateNormal];
    [searchButton setTitle:@"Search"
                  forState:UIControlStateNormal];
    searchButton.titleLabel.font = [UIFont boldSystemFontOfSize:14];
    [searchButton setTitleColor:[UIColor whiteColor]
                       forState:UIControlStateNormal];
    [searchButton addTarget:self
                     action:selector
           forControlEvents:UIControlEventTouchUpInside];
    [leftItemContainer addSubview:searchButton];
    //[leftItemContainer bringSubviewToFront:searchButton];
    
    UIBarButtonItem *leftBarButtonItem = [[[UIBarButtonItem alloc] initWithCustomView:leftItemContainer] autorelease];
    self.navigationItem.leftBarButtonItem = leftBarButtonItem;
    
    return searchField;
}

- (void)showLeftButtonWithImage:(NSString *)imageName
                    andSelector:(SEL)selector
{
    UIImage *buttonImage = [UIImage imageNamed:imageName];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
	[button setBackgroundImage:buttonImage
                      forState:UIControlStateNormal];
    [button setTitle:@"Back"
            forState:UIControlStateNormal];
    [button setTitleColor:[UIColor whiteColor]
                 forState:UIControlStateNormal];
    button.titleLabel.shadowColor = [UIColor darkGrayColor];
    button.titleLabel.shadowOffset = CGSizeMake(0, -1);
    button.titleLabel.font = [UIFont boldSystemFontOfSize:14];
    
	button.frame = CGRectMake(3, 5, 65, 27);
	[button addTarget:self
               action:selector
     forControlEvents:UIControlEventTouchUpInside];
    button.tag = kIntLeftItemTag;
    
    UIView *leftItemContainer = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, 100, 44)] autorelease];
    [leftItemContainer addSubview:button];
	
	UIBarButtonItem *customButton = [[[UIBarButtonItem alloc] initWithCustomView:leftItemContainer] autorelease];
	self.navigationItem.leftBarButtonItem = customButton;
    
    //  send left button item in the front of the navigation bar
    [self.navigationController.navigationBar bringSubviewToFront:leftItemContainer];
}

- (void)showLeftButtonWithImage:(NSString *)imageName andOverlay:(NSString *)overlayImageName andSelector:(SEL)selector
{
    UIImage *buttonImage = [UIImage imageNamed:imageName];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
	[button setBackgroundImage:buttonImage
                      forState:UIControlStateNormal];
    UIImage *overlayImage = [UIImage imageNamed:overlayImageName];
    [button setImage:overlayImage forState:UIControlStateNormal];
    [button setImageEdgeInsets:UIEdgeInsetsMake(0, 6, 0, 0)];
    
    //    button.showsTouchWhenHighlighted = YES;
	button.frame = CGRectMake(0, 0, buttonImage.size.width, buttonImage.size.height);
	[button addTarget:self
               action:selector
     forControlEvents:UIControlEventTouchUpInside];
	
	UIBarButtonItem *customButton = [[UIBarButtonItem alloc] initWithCustomView:button];
	self.navigationItem.leftBarButtonItem = customButton;
	[customButton release];
}

- (void)showLeftButtonWithImage:(NSString *)imageName andHighlighedImage:(NSString *)secondImageName andSelector:(SEL)selector
{
    UIImage *buttonImage = [UIImage imageNamed:imageName];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
	[button setBackgroundImage:buttonImage
                      forState:UIControlStateNormal];
    
    if (secondImageName)
        [button setBackgroundImage:[UIImage imageNamed:secondImageName]
                          forState:UIControlStateHighlighted];
    
    //    button.showsTouchWhenHighlighted = YES;
	button.frame = CGRectMake(0, 0, buttonImage.size.width, buttonImage.size.height);
    button.tag = kIntLeftItemTag;
	[button addTarget:self
               action:selector
     forControlEvents:UIControlEventTouchUpInside];
	
	UIBarButtonItem *customButton = [[UIBarButtonItem alloc] initWithCustomView:button];
	self.navigationItem.leftBarButtonItem = customButton;
	[customButton release];
}

- (void)showLeftButtonWithTitle:(NSString*)title andSelector:(SEL)selector
{
    UIBarButtonItem *button = [[UIBarButtonItem alloc] initWithTitle:title style:UIBarButtonItemStyleBordered target:self action:selector];
    self.navigationItem.leftBarButtonItem = button;
    [button release];
}

- (void)hideLeftButton
{
    self.navigationItem.leftBarButtonItem = nil;
}

- (NSInteger)showRightButtonWithImage:(NSString *)imageName andSelector:(SEL)selector
{
    //  init left button and set selector
    UIImage *buttonImage = [UIImage imageNamed:imageName];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
	[button setBackgroundImage:buttonImage
                      forState:UIControlStateNormal];
	button.frame = CGRectMake([UIScreen mainScreen].bounds.size.width - 65, 0, 55, 44);
	[button addTarget:self
               action:selector
     forControlEvents:UIControlEventTouchUpInside];
    button.tag = kIntRightItemTag;
    
    //  remove old item from navigation bar & add new item in the navigation bar
    UIView *oldLeftItem = [self.navigationController.navigationBar viewWithTag:kIntRightItemTag];
    if (oldLeftItem) {
        [oldLeftItem removeFromSuperview];
    }
    [self.navigationController.navigationBar addSubview:button];
    
    //	UIBarButtonItem *customButton = [[UIBarButtonItem alloc] initWithCustomView:button];
    //	self.navigationItem.leftBarButtonItem = customButton;
    //	[customButton release];
    
    return button.frame.size.width;
}

- (void)showRightButtonWithImage:(NSString *)imageName andSecondImageName:(NSString *)secondImageName andSelector:(SEL)selector
{
    UIImage *buttonImage = [UIImage imageNamed:imageName];
    
	UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
	[button setBackgroundImage:buttonImage
                      forState:UIControlStateNormal];
    
    
    if (secondImageName)
        [button setBackgroundImage:[UIImage imageNamed:secondImageName]
                          forState:UIControlStateHighlighted];
    
    //    button.showsTouchWhenHighlighted = YES;
	button.frame = CGRectMake(0, 0, buttonImage.size.width, buttonImage.size.height);
    button.tag = kIntRightItemTag;
	[button addTarget:self
               action:selector
     forControlEvents:UIControlEventTouchUpInside];
    
	UIBarButtonItem *customButton = [[UIBarButtonItem alloc] initWithCustomView:button];
	self.navigationItem.rightBarButtonItem = customButton;
	[customButton release];
}

- (void)hideRightButton
{
    self.navigationItem.rightBarButtonItem = nil;
}

- (void)showRightItem:(NSString *)imageName
{
    UIImage *itemImage = [UIImage imageNamed:imageName];
    UIImageView *rightView = [[UIImageView alloc] initWithImage:itemImage];
    rightView.frame = CGRectMake(320 - itemImage.size.width - 15, 8, itemImage.size.width, itemImage.size.height);
    rightView.tag = kIntRightItemTag;
    UIView *oldView = [self.navigationController.navigationBar viewWithTag:kIntRightItemTag];
    if (oldView ) {
        [oldView removeFromSuperview];
    }
    [self.navigationController.navigationBar addSubview:rightView];
    [rightView release];
}

- (void)hideRightItem
{
    UIView *rightView = [self.navigationController.navigationBar viewWithTag:kIntRightItemTag];
    if (rightView)
    {
        [rightView removeFromSuperview];
    }
}

- (void)showTitleBar
{
    UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Title"]];
    imageView.backgroundColor = [UIColor clearColor];
    self.navigationItem.titleView = imageView;
    [imageView release];
}

- (void)hideTitleBar
{
    self.navigationItem.titleView.hidden = YES;
}

- (void)showTitle:(NSString *)title
{
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, -3, 150, 44)];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.text = title;
    titleLabel.textColor = [UIColor whiteColor];
    [titleLabel setFont:[UIFont boldSystemFontOfSize:19]];
    titleLabel.shadowColor = [UIColor darkGrayColor];
    titleLabel.shadowOffset = CGSizeMake(0, -1);
    titleLabel.backgroundColor = [UIColor clearColor];
    //    NSLog(@"%@", [UIFont familyNames]);
    titleLabel.tag = kIntTitleTag;
    UIView *oldLabel = [self.navigationController.navigationBar viewWithTag:kIntTitleTag];
    [oldLabel removeFromSuperview];
    CGRect rect = CGRectMake(85, 0, 150, 44);
    UIView *container = [[[UIView alloc] initWithFrame:rect] autorelease];
    [container addSubview:titleLabel];
    [titleLabel release];
    [self.navigationController.navigationBar addSubview:container];
}

- (void)hideTitle
{
    UIView *titleLabel = [self.navigationController.navigationBar viewWithTag:kIntTitleTag];
    [titleLabel removeFromSuperview];
}

- (void)showInfoButton
{
    //  add info button to navigation bar
    UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeInfoLight];
    [infoButton addTarget:self action:@selector(onInfo) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *infoBarButton = [[UIBarButtonItem alloc] initWithCustomView:infoButton];
    self.navigationItem.leftBarButtonItem = infoBarButton;
    [infoBarButton release];
}

- (void)hideInfoButton
{
    self.navigationItem.leftBarButtonItem = nil;
}

- (void)resetNavigationBar
{
    //  reset navigation bar by removing old items from navigation bar
    UIView *oldItem = [self.navigationController.navigationBar viewWithTag:kIntLeftItemTag];
    if (oldItem) {
        [oldItem removeFromSuperview];
    }
    
    oldItem = [self.navigationController.navigationBar viewWithTag:kIntRightItemTag];
    if (oldItem) {
        [oldItem removeFromSuperview];
    }
    
    oldItem = [self.navigationController.navigationBar viewWithTag:kIntTitleTag];
    if (oldItem) {
        [oldItem removeFromSuperview];
    }
    
    oldItem = [self.navigationController.navigationBar viewWithTag:kIntSearchButton];
    if (oldItem) {
        [oldItem removeFromSuperview];
    }
    
    oldItem = [self.navigationController.navigationBar viewWithTag:kIntSearchField];
    if (oldItem) {
        [oldItem removeFromSuperview];
    }
}

#pragma mark - Action

#pragma mark - Utility

//  show loading gif image animated with dim background view
- (void)showLoading
{
    //  display diming background view behind the loading gif iamge view animated
    DimView *dimView = [[[DimView alloc] initWithFrame:self.view.bounds] autorelease];
    dimView.backgroundColor = [UIColor clearColor];
    dimView.tag = kIntLoadingViewTag;
    
    UIImage *frameImage = [UIImage imageNamed:@"frame1"];
    NSInteger width = frameImage.size.width;
    NSInteger height = frameImage.size.height;
    
    CGRect rect;
    rect = self.view.bounds;
    rect.origin.x = (rect.size.width - width) / 2;
    rect.origin.y = (rect.size.height - height) / 2;
    rect.size.width = width;
    rect.size.height = height;
    UIImageView* animatedImageView = [[[UIImageView alloc] initWithFrame:rect] autorelease];
    animatedImageView.animationImages = [NSArray arrayWithObjects:
                                         [UIImage imageNamed:@"frame10"],
                                         [UIImage imageNamed:@"frame1"],
                                         [UIImage imageNamed:@"frame2"],
                                         [UIImage imageNamed:@"frame3"],
                                         [UIImage imageNamed:@"frame4"],
                                         [UIImage imageNamed:@"frame5"],
                                         [UIImage imageNamed:@"frame6"],
                                         [UIImage imageNamed:@"frame7"],
                                         [UIImage imageNamed:@"frame8"],
                                         [UIImage imageNamed:@"frame9"],
                                         nil];
    animatedImageView.animationDuration = 1.5f;
    animatedImageView.animationRepeatCount = 1000;
    [animatedImageView startAnimating];
    [dimView addSubview: animatedImageView];
    [self.view addSubview:dimView];
}

//  hide loading view from this view
- (void)hideLoading
{
    UIView *loadingView = [self.view viewWithTag:kIntLoadingViewTag];
    [loadingView removeFromSuperview];
}

#pragma mark - View lifecycle

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.navigationController.navigationItem.hidesBackButton = YES;
    self.title = nil;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [self resetNavigationBar];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
