//
//  BMDetailVC.h
//  BathroomMap
//
//  Created by Xin Liang on 1/24/13.
//  Copyright (c) 2013 BLS Web Services. All rights reserved.
//

#import "BMBaseVC.h"
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>

@class BMLocation, BMMapVC, BMListVC;

@interface BMDetailVC : BMBaseVC <UITextFieldDelegate, UITextViewDelegate, UITableViewDataSource, UITableViewDelegate, MKMapViewDelegate, CLLocationManagerDelegate>

@property (nonatomic, assign) IBOutlet UIView *overView;
@property (nonatomic, assign) IBOutlet UIButton *descriptionButton;
@property (nonatomic, assign) IBOutlet UIButton *ratingButton;
@property (nonatomic, assign) IBOutlet UIButton *feedbackButton;
@property (nonatomic, assign) IBOutlet UIImageView *locationTypeImageView;
@property (nonatomic, assign) IBOutlet UILabel *locationNameLabel;
@property (nonatomic, assign) IBOutlet UILabel *addressLabel;
@property (nonatomic, assign) IBOutlet UILabel *linkLabel;
@property (nonatomic, assign) IBOutlet UILabel *phonenumberLabel;
@property (nonatomic, assign) IBOutlet MKMapView *mapView;
@property (nonatomic, assign) IBOutlet UIView *descriptionView;
@property (nonatomic, assign) IBOutlet UILabel *descriptionLabel;
@property (nonatomic, assign) IBOutlet UILabel *descriptionTitleLabel;
@property (nonatomic, assign) IBOutlet UILabel *moreLinkLabel;
@property (nonatomic, assign) IBOutlet UIView *ratingView;
@property (nonatomic, assign) IBOutlet UITableView *ratingTableView;
@property (nonatomic, assign) IBOutlet UIView *feedbackView;
@property (nonatomic, assign) IBOutlet UITextView *feedbackField;
@property (nonatomic, assign) IBOutlet UIButton *ratingGoodButton;
@property (nonatomic, assign) IBOutlet UIButton *ratingNormalButton;
@property (nonatomic, assign) IBOutlet UIButton *ratingBadButton;
@property (nonatomic, assign) IBOutlet UITextField *emailField;
@property (nonatomic, assign) IBOutlet UIButton *submitButton;
@property (nonatomic, assign) IBOutlet UIScrollView *scrollView;    //  scroll view to wrap description view part
@property (nonatomic, assign) IBOutlet UIButton *previousButton;    //  button to navigate to the previous button
@property (nonatomic ,assign) IBOutlet UIButton *nextButton;        //  button to navigate to the next button

@property (nonatomic, assign) IBOutlet UIButton *previousPressButton;    //  button to navigate to the previous button
@property (nonatomic ,assign) IBOutlet UIButton *nextPressButton;        //  button to navigate to the next button

@property (nonatomic, strong) BMLocation *location;             //  information for this location
@property (nonatomic, assign) BMMapVC *mapViewController;       //  parent view controller
@property (nonatomic, assign) BMListVC *listViewController;     //  parent view controller

- (IBAction)onDescription:(id)sender;
- (IBAction)onRating:(id)sender;
- (IBAction)onFeedback:(id)sender;
- (IBAction)onRatingGood:(id)sender;
- (IBAction)onRatingNormal:(id)sender;
- (IBAction)onRatingBad:(id)sender;
- (IBAction)onSubmit:(id)sender;
- (IBAction)onPrevious:(id)sender;
- (IBAction)onNext:(id)sender;

@end
