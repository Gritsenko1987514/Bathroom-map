//
//  BMDetailVC.m
//  BathroomMap
//
//  Created by Xin Liang on 1/24/13.
//  Copyright (c) 2013 BLS Web Services. All rights reserved.
//

#import "BMDetailVC.h"
#import "BMLocation.h"
#import "BMListVC.h"
#import <QuartzCore/QuartzCore.h>
#import "BMRatingCell.h"
#import "BMAnnotation.h"
#import "BMAnnotationView.h"
#import "BMMyLocationAnnotationView.h"
#import "BMMapVC.h"
#import "BMAPI.h"
#import "BMConstants.h"

@interface NSArray (BMLocation)

- (NSInteger)indexOfLocation:(BMLocation *)location;

@end

@implementation NSArray (BMLocation)

- (NSInteger)indexOfLocation:(BMLocation *)location
{
    NSInteger index = -1;
    
    for (int i = 0; i < self.count; i++) {
        BMLocation *element = (BMLocation *)[self objectAtIndex:i];
        if ([element.name isEqualToString:location.name] && element.latitude == location.latitude && element.longitude == location.longitude)
            return i;
    }
    
    return index;
}

@end

@interface BMDetailVC ()
{
    RateType rateType;
}

- (void)checkEnablingNavigator;
- (void)initView;
- (void)loadingData;
- (void)showDescriptionView;
- (void)showRatingView;
- (void)showFeedbackView;
- (void)onBack;
- (void)selectRatingGoodButton:(BOOL)selected;
- (void)selectRatingNormalButton:(BOOL)selected;
- (void)selectRatingBadButton:(BOOL)selected;
- (void)updateLocationInfo;

@end

@implementation BMDetailVC

@synthesize location = _location;

@synthesize mapViewController = _mapViewController;

@synthesize listViewController = _listViewController;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
    [_location release];
    [super dealloc];
}

#pragma mark - Action

- (IBAction)onPrevious:(id)sender
{
    if (_mapViewController)
    {
        int currentIndex = [_mapViewController.locationArray indexOfLocation:_location];
#ifdef DEBUG
        NSLog(@"currentIndex: %d", currentIndex);
#endif
        currentIndex = currentIndex - 1;
        if (currentIndex < 0)
            currentIndex = 0;
        self.location = [_mapViewController.locationArray objectAtIndex:currentIndex];
    }
    else if (_listViewController)
    {
        int currentIndex = [_listViewController.locationArray indexOfLocation:_location];
#ifdef DEBUG
        NSLog(@"currentIndex: %d", currentIndex);
#endif
        currentIndex = currentIndex - 1;
        if (currentIndex < 0)
            currentIndex = 0;
        self.location = [_listViewController.locationArray objectAtIndex:currentIndex];
    }
    [self loadingData];
    [self initView];

}

- (IBAction)onNext:(id)sender
{
    if (_mapViewController)
    {
        int currentIndex = [_mapViewController.locationArray indexOfLocation:_location];
#ifdef DEBUG
        NSLog(@"currentIndex: %d, location array count: %d", currentIndex, _mapViewController.locationArray.count);
#endif
        currentIndex = currentIndex + 1;
        if (currentIndex >= _mapViewController.locationArray.count)
            currentIndex = _mapViewController.locationArray.count - 1;
        self.location = [_mapViewController.locationArray objectAtIndex:currentIndex];
    }
    else if (_listViewController)
    {
        int currentIndex = [_listViewController.locationArray indexOfLocation:_location];
#ifdef DEBUG
        NSLog(@"currentIndex: %d, location array count: %d", currentIndex, _listViewController.locationArray.count);
#endif
        currentIndex = currentIndex + 1;
        if (currentIndex >= _listViewController.locationArray.count)
            currentIndex = _listViewController.locationArray.count - 1;
        self.location = [_listViewController.locationArray objectAtIndex:currentIndex];
    }
    [self loadingData];
    [self initView];
}

- (void)onBack
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)onDescription:(id)sender
{
    [self showDescriptionView];
}

- (IBAction)onRating:(id)sender
{
    [self showRatingView];
}

- (IBAction)onFeedback:(id)sender
{
    [self showFeedbackView];
}

- (IBAction)onRatingGood:(id)sender
{
    [self selectRatingGoodButton:YES];
    [self selectRatingNormalButton:NO];
    [self selectRatingBadButton:NO];
}

- (IBAction)onRatingNormal:(id)sender
{
    [self selectRatingGoodButton:NO];
    [self selectRatingNormalButton:YES];
    [self selectRatingBadButton:NO];
}

- (IBAction)onRatingBad:(id)sender
{
    [self selectRatingGoodButton:NO];
    [self selectRatingNormalButton:NO];
    [self selectRatingBadButton:YES];
}

- (IBAction)onSubmit:(id)sender
{
    [_feedbackField resignFirstResponder];
    [_emailField resignFirstResponder];
    
    [UIView animateWithDuration:0.5 animations:^{
        CGRect rect;
        rect = self.view.frame;
        if (rect.origin.y == 0)
            return;
        rect.origin.y += 170;
        self.view.frame = rect;
    }];
    
    NSString *rating = [NSString stringWithFormat:@"%d", rateType];
    NSString *username = [[NSUserDefaults standardUserDefaults] objectForKey:kUserName];
    NSString *emailaddress = [[NSUserDefaults standardUserDefaults] objectForKey:kEmailAddress];
    NSString *locationid = [NSString stringWithFormat:@"%d", _location.locationId];
    BOOL submit = [[BMAPI sharedInstance] submitFeedbackWithRating:rating user:username feedback:self.feedbackField.text email:emailaddress publish:@"0" locationid:locationid];
    
    if (submit)
    {
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        
        [self performSelector:@selector(updateLocationInfo) withObject:nil afterDelay:0.01];
    }
}

#pragma mark Private

//  @summary: check enabling next button and previous button with current location
- (void)checkEnablingNavigator
{
    if (_mapViewController)
    {
        NSInteger currentIndex = [_mapViewController.locationArray indexOfLocation:_location];
        if (currentIndex == -1)
        {
            _previousButton.enabled = NO;
            _previousPressButton.enabled = NO;
            _nextButton.enabled = NO;
            _nextPressButton.enabled = NO;
        }
        
        if (currentIndex < _mapViewController.locationArray.count - 1)
        {
            _nextButton.enabled = YES;
            _nextPressButton.enabled = YES;
        }
        else
        {
            _nextButton.enabled = NO;
            _nextPressButton.enabled = NO;
        }
        
        if (currentIndex > 0)
        {
            _previousButton.enabled = YES;
            _previousPressButton.enabled = YES;
        }
        else
        {
            _previousButton.enabled = NO;
            _previousPressButton.enabled = NO;
        }
    }
    else if (_listViewController)
    {
        NSInteger currentIndex = [_listViewController.locationArray indexOfLocation:_location];
        if (currentIndex == -1)
        {
            _previousButton.enabled = NO;
            _previousPressButton.enabled = NO;
            _nextButton.enabled = NO;
            _nextPressButton.enabled = NO;
        }
        
        if (currentIndex < _listViewController.locationArray.count - 1)
        {
            _nextButton.enabled = YES;
            _nextPressButton.enabled = YES;
        }
        else
        {
            _nextButton.enabled = NO;
            _nextPressButton.enabled = NO;
        }
        
        if (currentIndex > 0)
        {
            _previousButton.enabled = YES;
            _previousPressButton.enabled = YES;
        }
        else
        {
            _previousPressButton.enabled = NO;
            _previousButton.enabled = NO;
        }
    }
}

//  @summary: show type view
- (void)showDescriptionView
{
    _descriptionView.alpha = 1;
    _ratingView.alpha = 0;
    _feedbackView.alpha = 0;

    //  add all views to scroll view of description view
    [_scrollView addSubview:_overView];
    
    _mapView.alpha = 1;
    
    //  adjust frame of over view
    CGRect rect = _overView.frame;
    rect.origin.y = 100;
    _overView.frame = rect;
    
    rect = _descriptionView.frame;
    rect.origin.y = 265;
    _descriptionView.frame = rect;
    
    _scrollView.contentOffset = CGPointZero;
    float height = _mapView.frame.size.height + _overView.frame.size.height + _descriptionView.frame.size.height;
    _scrollView.contentSize = CGSizeMake(320, height + 150);
    _scrollView.scrollEnabled = YES;
}

//  @summary: show rating view
- (void)showRatingView
{
    [_scrollView scrollRectToVisible:CGRectMake(0, 0, 320, 10)
                            animated:NO];
    
    _descriptionView.alpha = 0;
    _ratingView.alpha = 1;
    _feedbackView.alpha = 0;
    [_ratingTableView reloadData];
    
    _scrollView.scrollEnabled = NO;
    
    //  adjust frame of over view
    [UIView animateWithDuration:0.5 animations:^{
        _mapView.alpha = 0;
        CGRect rect = _overView.frame;
        rect.origin.y = -10;
        _overView.frame = rect;
    }];
}

//  @summary: show feedback view
- (void)showFeedbackView
{
    [_scrollView scrollRectToVisible:CGRectMake(0, 0, 320, 10)
                            animated:NO];
    _descriptionView.alpha = 0;
    _ratingView.alpha = 0;
    _feedbackView.alpha = 1;
    
    _scrollView.scrollEnabled = NO;
    
    //  adjust frame of overview
    [UIView animateWithDuration:0.5 animations:^{
        _mapView.alpha = 0;
        CGRect rect = _overView.frame;
        rect.origin.y = -10;
        _overView.frame = rect;
    }];
}

//  @summary: select/unselect rating good button
- (void)selectRatingGoodButton:(BOOL)selected
{
    if (selected)
    {
        _ratingGoodButton.layer.borderColor = [[UIColor colorWithRed:0.49 green:0.667 blue:0.345 alpha:1] CGColor];
        _ratingGoodButton.layer.borderWidth = 1.5f;
        
        rateType = RateTypeGood;
    }
    else{
        _ratingGoodButton.layer.borderWidth = 0;
    }
}

//  @summary: select/unselect rating normal button
- (void)selectRatingNormalButton:(BOOL)selected
{
    if (selected)
    {
        _ratingNormalButton.layer.borderColor = [[UIColor colorWithRed:0.875 green:0.678 blue:0.337 alpha:1] CGColor];
        _ratingNormalButton.layer.borderWidth = 1.5f;
        
        rateType = RateTypeNormal;
    }
    else
    {
        _ratingNormalButton.layer.borderWidth = 0;
    }
}

//  @summary: select/unselect rating bad button
- (void)selectRatingBadButton:(BOOL)selected
{
    if (selected)
    {
        _ratingBadButton.layer.borderColor = [[UIColor colorWithRed:0.761 green:0.294 blue:0.22 alpha:1] CGColor];
        _ratingBadButton.layer.borderWidth = 1.5f;
        
        rateType = RateTypeBad;
    }
    else
    {
        _ratingBadButton.layer.borderWidth = 0;
    }
}

- (void)updateLocationInfo
{
    NSArray *locationArray = [[BMAPI sharedInstance] getLocations];
    AppDelegate.locationArray = [[locationArray mutableCopy] autorelease];
    
    int currentIndex = -1;
    if (_mapViewController)
        currentIndex = [_mapViewController.locationArray indexOfLocation:_location];
    else if (_listViewController)
        currentIndex = [_listViewController.locationArray indexOfLocation:_location];
    _location = [locationArray objectAtIndex:currentIndex];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:kNotificationDidFinishUpdate object:nil];
    
    [MBProgressHUD hideHUDForView:self.view animated:YES];
}

//  @summary: loading data
- (void)loadingData
{

}

//  @summary: initialize this view
- (void)initView
{
    //  remove all subviews of this view
    for (UIView *subview in self.view.subviews) {
        [subview removeFromSuperview];
    }
    
    [[NSBundle mainBundle] loadNibNamed:@"BMDetailVC"
                                  owner:self
                                options:nil];
    
    //  add padding to email field of leave feedback view
    _emailField.leftView = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, 10, 20)] autorelease];
    _emailField.leftViewMode = UITextFieldViewModeAlways;
    _emailField.rightView = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, 10, 20)] autorelease];
    _emailField.rightViewMode = UITextFieldViewModeAlways;
    
    /*****************************************************************************
     * init map view
     *****************************************************************************/
    CLLocationCoordinate2D coordinate;
    
    //  set center location and range
    coordinate.latitude = _location.latitude;
    coordinate.longitude = _location.longitude;
    
    MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(coordinate, 100, 100);
    [_mapView setRegion:region
               animated:NO];
    [_mapView setShowsUserLocation:YES];
    
    //  build annotation model for this map view
    BMAnnotation *annotation = nil;
    coordinate.latitude = _location.latitude;
    coordinate.longitude = _location.longitude;
    annotation = [[[BMAnnotation alloc] initWithCoordinate:coordinate
                                                     title:_location.name
                                                  subtitle:_location.name
                                                  location:_location] autorelease];
    [_mapView addAnnotation:annotation];
    
    [self.mapView setNeedsLayout];
    [self.mapView setNeedsDisplay];

    //self.mapView.userInteractionEnabled = NO;
    
    //  init over view
    _locationNameLabel.text = _location.name;
    _addressLabel.text = _location.location;
    _phonenumberLabel.text = _location.phone;
    _linkLabel.text = _location.website;
    switch (_location.category) {
        case LocationCategoryAirport:
            _locationTypeImageView.image = [UIImage imageNamed:@"IconAirplane"];
            break;
//        case LocationCategoryCampsite:
//            _locationTypeImageView.image = [UIImage imageNamed:@"IconCampsite"];
//            break;
        case LocationCategoryCoffeehouse:
            _locationTypeImageView.image = [UIImage imageNamed:@"IconCoffee"];
            break;
//        case LocationCategoryGasStation:
//            _locationTypeImageView.image = [UIImage imageNamed:@"IconGasStation"];
//            break;
        case LocationCategoryHotel:
            _locationTypeImageView.image = [UIImage imageNamed:@"IconHotel"];
            break;
//        case LocationCategoryParkingArea:
//            _locationTypeImageView.image = [UIImage imageNamed:@"IconParkingarea"];
//            break;
        case LocationCategoryRestaurant:
            _locationTypeImageView.image = [UIImage imageNamed:@"IconRestaurant"];
            break;
            
        default:
            break;
    }
    _descriptionLabel.text = _location.locationDescription;
    
    //  show type view in default
    [self showDescriptionView];
    
    //  check enabling of navigator buttons
    [self checkEnablingNavigator];
    
    //  show init info for rate
    [self selectRatingGoodButton:YES];
}

#pragma mark - UITextFieldDelegate

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    [UIView animateWithDuration:0.5 animations:^{
        CGRect rect;
        rect = self.view.frame;
        if (rect.origin.y != 0)
            return;
        rect.origin.y -= 170;
        self.view.frame = rect;
    }];
    
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField)
    {
        [textField resignFirstResponder];
        
        [UIView animateWithDuration:0.5 animations:^{
            CGRect rect;
            rect = self.view.frame;
            if (rect.origin.y == 0)
                return;
            rect.origin.y += 170;
            self.view.frame = rect;
        }];
    }
    
    return YES;
}

#pragma mark - UITextViewDelegate

- (void)textViewDidBeginEditing:(UITextView *)textView
{
    [UIView animateWithDuration:0.5 animations:^{
        CGRect rect;
        rect = self.view.frame;
        if (rect.origin.y != 0)
            return;
        rect.origin.y -= 170;
        self.view.frame = rect;
    }];
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if ([text isEqualToString:@"\n"])
    {
        [textView resignFirstResponder];
        [UIView animateWithDuration:0.5 animations:^{
            CGRect rect;
            rect = self.view.frame;
            if (rect.origin.y == 0)
                return;
            rect.origin.y += 170;
            self.view.frame = rect;
        }];
    }
    
    return YES;
}

#pragma mark - UITableViewDelegate
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    BMRatingCell *cell = nil;
    UIViewController *viewController = [[[UIViewController alloc] initWithNibName:@"BMRatingCell" bundle:nil] autorelease];
    cell = (BMRatingCell *)viewController.view;
    
    BMFeedback *rating = [_location.feedbackArray objectAtIndex:indexPath.row];
    cell.rating = rating;
    
    [cell configRatingCell];
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    BMFeedback *rating = [_location.feedbackArray objectAtIndex:indexPath.row];
    NSString *feedback = rating.feedback;
    CGSize constrainSize = CGSizeMake(172, CGFLOAT_MAX);
    CGSize stringSize = [BMUtility sizeOfString:feedback
                             andConstrainedSize:constrainSize
                                    andFontSize:13.0f];
    NSInteger height = stringSize.height + 15;
    return MAX(height, 78);
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _location.feedbackArray.count;
}

#pragma mark - MKMapViewDelegate

- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation
{
    // If it's the user location, just return nil.
    if ([annotation isKindOfClass:[MKUserLocation class]])
    {
        BMMyLocationAnnotationView *myLocationView = nil;
        //  create new pin
        myLocationView = [[[BMMyLocationAnnotationView alloc] initWithAnnotation:annotation
                                                                 reuseIdentifier:nil]
                          autorelease];
        myLocationView.annotation = annotation;
        
        //  display callout view of current selected pin
        
        return myLocationView;
    }
    
    if ([annotation isKindOfClass:[BMAnnotation class]])
    {
        NSString *annotationIdentifier = @"PinAnnotationView";
        
        BMAnnotationView *pinView =
        (BMAnnotationView *)[mapView dequeueReusableAnnotationViewWithIdentifier:annotationIdentifier];
        
        if (!pinView)
        {
            //  create new pin
            pinView = [[[BMAnnotationView alloc] initWithAnnotation:annotation
                                                    reuseIdentifier:annotationIdentifier]
                       autorelease];
            
            [pinView setCanShowCallout:NO];
            [pinView setDraggable:NO];
            [pinView setEnabled:NO];
            
            //  set pin image along the type of location
            BMAnnotation *bmAnnotation = (BMAnnotation *)annotation;
            switch (bmAnnotation.location.category) {
                case LocationCategoryAirport:
                    [pinView setImage:[UIImage imageNamed:@"PinHotel"]];
                    break;
//                case LocationCategoryCampsite:
//                    [pinView setImage:[UIImage imageNamed:@"PinHotel"]];
//                    break;
                case LocationCategoryCoffeehouse:
                    [pinView setImage:[UIImage imageNamed:@"IconCoffee"]];
                    break;
//                case LocationCategoryGasStation:
//                    [pinView setImage:[UIImage imageNamed:@"PinGasstation"]];
//                    break;
                case LocationCategoryHotel:
                    [pinView setImage:[UIImage imageNamed:@"PinHotel"]];
                    break;
//                case LocationCategoryParkingArea:
//                    [pinView setImage:[UIImage imageNamed:@"PinParkarea"]];
//                    break;
                case LocationCategoryRestaurant:
                    [pinView setImage:[UIImage imageNamed:@"PinHotel"]];
                    break;
                    
                default:
                    break;
            }
        }
        else
        {
            //  set annotation for this pin
            pinView.annotation = annotation;
        }
        
        //  display callout view of current selected pin
        
        return pinView;
    }
    
    return nil;
}

- (void)mapView:(MKMapView *)mapView didSelectAnnotationView:(MKAnnotationView *)view
{
    
}

- (void)mapView:(MKMapView *)mapView didDeselectAnnotationView:(MKAnnotationView *)view
{
    
}

- (void)mapView:(MKMapView *)mapView
 annotationView:(MKAnnotationView *)view
calloutAccessoryControlTapped:(UIControl *)control
{
#ifdef DEBUG
    NSLog(@"callout accesssory control tapped");
#endif
}

-(void)mapView:(MKMapView *)mapView regionDidChangeAnimated:(BOOL)animated {
    
}

#pragma mark - View LifeCycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.

    //  loading data
    [self loadingData];
    
    //  init view
    [self initView];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [self showTitle:@"Location"];
    
    [self showRightButtonWithImage:@"TagButton"
                       andSelector:nil];
    
    [self showLeftButtonWithImage:@"BackButton"
                      andSelector:@selector(onBack)];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
