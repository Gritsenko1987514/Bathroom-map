//
//  BMFeedbackFormVC.m
//  BathroomMap
//
//  Created by Xin Liang on 1/24/13.
//  Copyright (c) 2013 BLS Web Services. All rights reserved.
//

#import "BMFeedbackFormVC.h"

@interface BMFeedbackFormVC ()

@end

@implementation BMFeedbackFormVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
