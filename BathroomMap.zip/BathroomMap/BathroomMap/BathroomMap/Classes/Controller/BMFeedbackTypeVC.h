//
//  BMFeedbackTypeVC.h
//  BathroomMap
//
//  Created by Xin Liang on 1/24/13.
//  Copyright (c) 2013 BLS Web Services. All rights reserved.
//

#import "BMBaseVC.h"

@interface BMFeedbackTypeVC : BMBaseVC

@end
