//
//  BMListVC.h
//  BathroomMap
//
//  Created by Xin Liang on 1/23/13.
//  Copyright (c) 2013 BLS Web Services. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BMBaseVC.h"

@interface BMListVC : BMBaseVC <UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate>

@property (nonatomic, assign) IBOutlet UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *locationArray;    //  array of all locations
@property (nonatomic, strong) UITextField *searchField;

@end
