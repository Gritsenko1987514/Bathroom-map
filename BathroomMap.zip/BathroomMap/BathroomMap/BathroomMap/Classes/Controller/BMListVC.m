//
//  BMListVC.m
//  BathroomMap
//
//  Created by Xin Liang on 1/23/13.
//  Copyright (c) 2013 BLS Web Services. All rights reserved.
//

#import "BMListVC.h"
#import "BMListCell.h"
#import "BMLocation.h"

@interface BMListVC ()

- (void)updateTableView;

@end

@implementation BMListVC

@synthesize tableView = _tableView;
@synthesize locationArray = _locationArray;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
    [_locationArray release];
    [super dealloc];
}

- (void)updateTableView
{
    [self.tableView reloadData];
}

#pragma mark - UITextFieldDelegate

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    self.searchField = textField;
    
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField)
        [textField resignFirstResponder];
    
    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    if (searchKey)
        [searchKey release];
    searchKey = [textField.text retain];
    
    [self.tableView reloadData];
}

#pragma mark - UITableViewDelegate

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    BMListCell *cell = nil;
    
    UIViewController *viewController = [[[UIViewController alloc] initWithNibName:@"BMListCell"
                                                                           bundle:nil] autorelease];
    cell = (BMListCell *)viewController.view;
    
    BMLocation *location = [searchLocationArray objectAtIndex:indexPath.row];
    cell.location = location;
    cell.viewController = self;
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 49;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (searchLocationArray)
        [searchLocationArray release];
    if (searchKey.length == 0)
        searchLocationArray = [[NSMutableArray arrayWithArray:_locationArray] retain];
    else
    {
        searchLocationArray = [[NSMutableArray alloc] init];
        for (int i = 0; i < _locationArray.count; i++) {
            BMLocation *location = [_locationArray objectAtIndex:i];
            if ([[location.name lowercaseString] rangeOfString:[searchKey lowercaseString]].location != NSNotFound)
                [searchLocationArray addObject:location];
        }
    }
    
    return searchLocationArray.count;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}

#pragma mark - View LifeCycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    _locationArray = AppDelegate.locationArray;
    
    searchKey = [@"" retain];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didFinishUpdate) name:kNotificationDidFinishUpdate object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateTableView) name:kNotificationDidUpdateCurrentLocation object:nil];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    self.searchField = [self showTextField:self andSelector:@selector(onSearch)];
    self.searchField.text = searchKey;
    
    [self showRightButtonWithImage:@"TagButton" andSelector:nil];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    self.searchField = [self showTextField:self andSelector:@selector(onSearch)];
    self.searchField.text = searchKey;
    
    [self showRightButtonWithImage:@"TagButton" andSelector:nil];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)didFinishUpdate
{
    _locationArray = AppDelegate.locationArray;
    
    [self.tableView reloadData];
}

- (void)onSearch
{
    [self.searchField resignFirstResponder];
}

@end
