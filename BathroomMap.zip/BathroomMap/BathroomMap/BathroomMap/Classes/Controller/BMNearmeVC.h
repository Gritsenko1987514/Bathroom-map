//
//  BMNearmeVC.h
//  BathroomMap
//
//  Created by Xin Liang on 2/17/13.
//  Copyright (c) 2013 BLS Web Services. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BMBaseVC.h"
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>
#import "BMCalloutAnnotationView.h"

@interface BMNearmeVC : BMBaseVC <UITextFieldDelegate, MKMapViewDelegate, CLLocationManagerDelegate, BMCalloutAnnotationViewDelegate>

@property (nonatomic, assign) IBOutlet MKMapView *mapView;
@property (nonatomic, strong) NSMutableArray *locationArray;
@property (nonatomic, strong) NSMutableArray *annotationArray;
@property (nonatomic, strong) UITextField *searchField;

@end
