//
//  BMNearmeVC.m
//  BathroomMap
//
//  Created by Xin Liang on 2/17/13.
//  Copyright (c) 2013 BLS Web Services. All rights reserved.
//

#import "BMNearmeVC.h"
#import "BMLocation.h"
#import "BMAnnotation.h"
#import "BMAnnotationView.h"
#import "BMCalloutAnnotationView.h"
#import "BMCalloutAnnotation.h"
#import "BMDetailVC.h"
#import "BMListVC.h"
#import "BMLocation.h"
#import "BMMyLocationAnnotationView.h"
#import "BMConstants.h"

@interface BMNearmeVC ()
{
    CLLocationManager *locationManager;
}

- (void)initView;
- (void)displayCalloutView:(id<MKAnnotation>)currentAnnotation;
- (void)handleLongPress:(UIGestureRecognizer *)gestureRecognizer;
- (void)updateLocation;

@end

@implementation BMNearmeVC

@synthesize mapView = _mapView;
@synthesize locationArray = _locationArray;
@synthesize annotationArray = _annotationArray;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
    [_locationArray release];
    [_annotationArray release];
    [locationManager release];
    [searchKey release];
    
    [super dealloc];
}

#pragma mark - Action

#pragma mark - UITextFieldDelegate

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    self.searchField = textField;
    
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField)
        [textField resignFirstResponder];
    
    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    if (searchKey)
        [searchKey release];
    searchKey = [textField.text retain];
    
    [self updateLocation];
}

#pragma mark - MKMapViewDelegate

- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation
{
    // If it's the user location, just return nil.
    if ([annotation isKindOfClass:[MKUserLocation class]])
    {
        BMMyLocationAnnotationView *myLocationView = nil;
        //  create new pin
        myLocationView = [[[BMMyLocationAnnotationView alloc] initWithAnnotation:annotation
                                                                 reuseIdentifier:nil]
                          autorelease];
        myLocationView.annotation = annotation;
        
        //  display callout view of current selected pin
        return myLocationView;
    }
    
    if ([annotation isKindOfClass:[BMAnnotation class]])
    {
        BMAnnotation *bmAnnotation = (BMAnnotation *)annotation;
        
        if (bmAnnotation.isCurrentLocation == YES)
        {
            BMMyLocationAnnotationView *myLocationView = nil;
            //  create new pin
            myLocationView = [[[BMMyLocationAnnotationView alloc] initWithAnnotation:annotation
                                                                     reuseIdentifier:nil]
                              autorelease];
            myLocationView.annotation = annotation;
            
            //  display callout view of current selected pin
            return myLocationView;
        }
        
        NSString *annotationIdentifier = @"PinAnnotationView";
        
        BMAnnotationView *pinView = (BMAnnotationView *)[mapView dequeueReusableAnnotationViewWithIdentifier:annotationIdentifier];
        
        if (!pinView)
        {
            //  create new pin
            pinView = [[[BMAnnotationView alloc] initWithAnnotation:annotation
                                                    reuseIdentifier:annotationIdentifier]
                       autorelease];
            
            pinView.mapViewController = (BMMapVC*)self;
            
            //  set pin image along the type of location
            
            switch (bmAnnotation.location.category) {
                case LocationCategoryAirport:
                    [pinView setImage:[UIImage imageNamed:@"PinHotel"]];
                    break;
//                case LocationCategoryCampsite:
//                    [pinView setImage:[UIImage imageNamed:@"PinHotel"]];
//                    break;
                case LocationCategoryCoffeehouse:
                    [pinView setImage:[UIImage imageNamed:@"PinHotel"]];
                    break;
//                case LocationCategoryGasStation:
//                    [pinView setImage:[UIImage imageNamed:@"PinGasstation"]];
//                    break;
                case LocationCategoryHotel:
                    [pinView setImage:[UIImage imageNamed:@"PinHotel"]];
                    break;
//                case LocationCategoryParkingArea:
//                    [pinView setImage:[UIImage imageNamed:@"PinParkarea"]];
//                    break;
                case LocationCategoryRestaurant:
                    [pinView setImage:[UIImage imageNamed:@"PinHotel"]];
                    break;
                    
                default:
                    break;
            }
        }
        else
        {
            //  set annotation for this pin
            pinView.annotation = annotation;
        }
        
        //  display callout view of current selected pin
        
        return pinView;
    }
    
    return nil;
}

- (void)mapView:(MKMapView *)mapView didSelectAnnotationView:(MKAnnotationView *)view
{
    if ([view.annotation isKindOfClass:[BMAnnotation class]])
    {
        [UIView animateWithDuration:1 animations:^{
            BMAnnotation *bmAnnotation = (BMAnnotation *)view.annotation;
            [_mapView setCenterCoordinate:bmAnnotation.coordinate animated:YES];
        }];
    }
}

- (void)mapView:(MKMapView *)mapView didDeselectAnnotationView:(MKAnnotationView *)view
{
}

- (void)mapView:(MKMapView *)mapView annotationView:(MKAnnotationView *)view calloutAccessoryControlTapped:(UIControl *)control
{
#ifdef DEBUG
    NSLog(@"callout accesssory control tapped");
#endif
}

-(void)mapView:(MKMapView *)mapView regionDidChangeAnimated:(BOOL)animated
{
    
}

#pragma mark - BMCalloutAnnotationViewDelegate

- (void)didSelectDetail:(BMLocation *)location
{
    //  go to the detail page of the this location
    //[AppDelegate.tabbarController selectTab:1];
    UINavigationController *navigationController = (UINavigationController *)AppDelegate.tabbarController.selectedViewController;
    BMListVC *vc = (BMListVC *)[navigationController.viewControllers objectAtIndex:0];
    [vc.navigationController popToRootViewControllerAnimated:NO];
    BMDetailVC *detailVC = [[[BMDetailVC alloc] initWithNibName:@"BMDetailVC"
                                                         bundle:nil] autorelease];
    detailVC.location = location;
    detailVC.mapViewController = (BMMapVC*)self;
    detailVC.listViewController = nil;
    [vc.navigationController pushViewController:detailVC
                                       animated:YES];
}

- (void)didSelectDirection:(BMLocation *)location
{
    
}

#pragma mark - Private

//  @summary: handle long press gesture for map view
- (void)handleLongPress:(UIGestureRecognizer *)gestureRecognizer {
    if (gestureRecognizer.state != UIGestureRecognizerStateBegan)
        return;
	if([gestureRecognizer isMemberOfClass:[UILongPressGestureRecognizer class]] && (gestureRecognizer.state == UIGestureRecognizerStateEnded)) {
		[_mapView removeGestureRecognizer:gestureRecognizer]; //avoid multiple pins to appear when holding on the screen
    }
}

- (void)updateLocation
{
    /******************************************************************
     * update map view
     ******************************************************************/
    if (_annotationArray)
        [_mapView removeAnnotations:_annotationArray];
    
    CLLocationCoordinate2D coordinate;
    CLLocationCoordinate2D currentCoordinate = locationManager.location.coordinate;
    
    //  set center location and range
    if (!_locationArray) return;
    if (_locationArray.count == 0)   return;
    
    //  build annotation model for this map view
    if (_annotationArray)
        [_annotationArray release];
    _annotationArray = [[NSMutableArray alloc] init];
    for (BMLocation *location in _locationArray)
    {
        BMAnnotation *annotation = nil;
        coordinate.latitude = location.latitude;
        coordinate.longitude = location.longitude;
        
        if (searchKey.length > 0)
        {
            if ([[location.name lowercaseString] rangeOfString:[searchKey lowercaseString]].location == NSNotFound)
                continue;
        }
        
        float distance = [BMUtility calculateDistanceBetweenSource:currentCoordinate destination:coordinate];
        if (distance > kMaxDistance)
            continue;
        
        annotation = [[[BMAnnotation alloc] initWithCoordinate:coordinate
                                                         title:location.name
                                                      subtitle:location.name
                                                      location:location] autorelease];
        [_mapView addAnnotation:annotation];
        [_annotationArray addObject:annotation];
    }
    
    [self.mapView setNeedsLayout];
    [self.mapView setNeedsDisplay];
}

//  @summary: popup callout view of specific annotation
- (void)displayCalloutView:(id<MKAnnotation>)currentAnnotation
{
    //  set center location and range
    
    if ( _locationArray == nil || [_locationArray count] == 0) {
        return;
    }
    
    CLLocationCoordinate2D coordinate;
    BMLocation *location = [_locationArray objectAtIndex:0];
    coordinate.latitude = location.latitude;
    coordinate.longitude = location.longitude;
    
    MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(coordinate, 1000, 1000);
    [_mapView setRegion:region
               animated:NO];
    [_mapView selectAnnotation:currentAnnotation animated:YES];
    [_mapView setNeedsDisplay];
    [_mapView setNeedsLayout];
}

//  @summary: init this view
- (void)initView
{
    /******************************************************************
     * init map view
     ******************************************************************/
    if (_annotationArray)
    {
        [_mapView removeAnnotations:_annotationArray];
        [_annotationArray release];
    }
    
    CLLocationCoordinate2D coordinate;
    CLLocationCoordinate2D currentLocation = locationManager.location.coordinate;
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    [userDefault setObject:[NSNumber numberWithFloat:currentLocation.latitude] forKey:kCurrentLat];
    [userDefault setObject:[NSNumber numberWithFloat:currentLocation.longitude] forKey:kCurrentLon];
    [userDefault synchronize];
    
    //  set center location and range
    if (!_locationArray) return;
    if (_locationArray.count == 0)   return;

    MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(currentLocation, 1000, 1000);
    [_mapView setRegion:region animated:NO];
    //[_mapView setShowsUserLocation:YES];
    BMAnnotation *annotation = [[[BMAnnotation alloc] initWithCoordinate:currentLocation
                                                     title:@"Location"
                                                  subtitle:@"Current Location"
                                                  location:nil] autorelease];
    annotation.isCurrentLocation = YES;
    [_mapView addAnnotation:annotation];
    //  build annotation model for this map view
    _annotationArray = [[NSMutableArray alloc] init];
    for (BMLocation *location in _locationArray)
    {
        annotation = nil;
        coordinate.latitude = location.latitude;
        coordinate.longitude = location.longitude;
        
        if (searchKey.length > 0)
        {
            if ([[location.name lowercaseString] rangeOfString:[searchKey lowercaseString]].location == NSNotFound)
                continue;
        }
        
        float distance = [BMUtility calculateDistanceBetweenSource:currentLocation destination:coordinate];
        if (distance > kMaxDistance)
            continue;
        
        annotation = [[[BMAnnotation alloc] initWithCoordinate:coordinate
                                                         title:location.name
                                                      subtitle:location.name
                                                      location:location] autorelease];
        [_mapView addAnnotation:annotation];
        [_annotationArray addObject:annotation];
    }
    
    [self.mapView setNeedsLayout];
    [self.mapView setNeedsDisplay];
}

#pragma mark - View LifeCycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    searchKey = [@"" retain];
    // Create Location Manager
    locationManager = [[CLLocationManager alloc] init];
    locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    locationManager.delegate = self;
    [locationManager startUpdatingLocation];
    
    //  loading data
    self.locationArray = AppDelegate.locationArray;
    
    //  init view
    [self initView];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didFinishUpdate) name:kNotificationDidFinishUpdate object:nil];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    self.searchField = [self showTextField:self andSelector:@selector(onSearch)];
    self.searchField.text = searchKey;
    
    [self showRightButtonWithImage:@"TagButton" andSelector:nil];
    
    //  refresh map view
    //  [self displayCalloutView:[_annotationArray objectAtIndex:0]];
    [_mapView setNeedsDisplay];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    self.searchField = [self showTextField:self andSelector:@selector(onSearch)];
    self.searchField.text = searchKey;
    
    [self showRightButtonWithImage:@"TagButton" andSelector:@selector(currentLocation)];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)didFinishUpdate
{
    self.locationArray = AppDelegate.locationArray;
    
    if (_annotationArray)
    {
        [_mapView removeAnnotations:_annotationArray];
        [_annotationArray release];
    }
    
    CLLocationCoordinate2D coordinate;
    CLLocationCoordinate2D currentCoordinate = locationManager.location.coordinate;
    
    //  set center location and range
    if (!_locationArray) return;
    if (_locationArray.count == 0)   return;
    //  build annotation model for this map view
    _annotationArray = [[NSMutableArray alloc] init];
    for (BMLocation *location in _locationArray)
    {
        BMAnnotation *annotation = nil;
        coordinate.latitude = location.latitude;
        coordinate.longitude = location.longitude;
        
        if (searchKey.length > 0)
        {
            if ([[location.name lowercaseString] rangeOfString:[searchKey lowercaseString]].location == NSNotFound)
                continue;
        }
        
        float distance = [BMUtility calculateDistanceBetweenSource:currentCoordinate destination:coordinate];
        if (distance > kMaxDistance)
            continue;
        
        annotation = [[[BMAnnotation alloc] initWithCoordinate:coordinate
                                                         title:location.name
                                                      subtitle:location.name
                                                      location:location] autorelease];
        [_mapView addAnnotation:annotation];
        [_annotationArray addObject:annotation];
    }
    
    [self.mapView setNeedsLayout];
    [self.mapView setNeedsDisplay];
}

- (void)onSearch
{
    [self.searchField resignFirstResponder];
}

- (void)currentLocation
{
    [self.mapView setCenterCoordinate:locationManager.location.coordinate];
}

#pragma mark - CLLocationManagerDelegate
- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    [self updateLocation];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    [userDefault setObject:[NSNumber numberWithFloat:newLocation.coordinate.latitude] forKey:kCurrentLat];
    [userDefault setObject:[NSNumber numberWithFloat:newLocation.coordinate.longitude] forKey:kCurrentLon];
    
    [userDefault synchronize];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:kNotificationDidUpdateCurrentLocation object:nil];
}

- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations
{
    
}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    
}

@end
