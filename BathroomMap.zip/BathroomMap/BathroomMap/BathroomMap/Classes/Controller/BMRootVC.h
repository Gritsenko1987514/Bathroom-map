//
//  BMRootVC.h
//  BathroomMap
//
//  Created by Xin Liang on 1/23/13.
//  Copyright (c) 2013 BLS Web Services. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BMRootVC : UIViewController

@property (nonatomic, strong) UIViewController *contentViewController;

- (void)addContentViewController:(UIViewController *)viewController;

@end
