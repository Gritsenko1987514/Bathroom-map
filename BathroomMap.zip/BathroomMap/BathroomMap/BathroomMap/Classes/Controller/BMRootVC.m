//
//  BMRootVC.m
//  BathroomMap
//
//  Created by Xin Liang on 1/23/13.
//  Copyright (c) 2013 BLS Web Services. All rights reserved.
//

#import "BMRootVC.h"

@interface BMRootVC ()

@end

@implementation BMRootVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
    [_contentViewController release];
    [super dealloc];
}

#pragma mark - Utility

//  @summary: set view controller for the content view of this view
//  @param: viewController: view controller to set as content view of this root view
- (void)addContentViewController:(UIViewController *)viewController
{
    if (!viewController)
        return;
    
    if (!viewController.view)
        return;
    
    self.contentViewController = viewController;
    
    //  add content view
    CGRect rect = viewController.view.frame;
    rect.origin.y = 30;
    viewController.view.frame = rect;
    [self.view addSubview:viewController.view];
    [self.view sendSubviewToBack:viewController.view];
}

#pragma mark - View LifeCycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
