//
//  BMSettingVC.h
//  BathroomMap
//
//  Created by Xin Liang on 1/24/13.
//  Copyright (c) 2013 BLS Web Services. All rights reserved.
//

#import "BMBaseVC.h"

@interface BMSettingVC : BMBaseVC <UITextFieldDelegate>

@property (strong, nonatomic) IBOutlet UITextField *firstNameField;
@property (strong, nonatomic) IBOutlet UITextField *lastNameField;
@property (strong, nonatomic) IBOutlet UITextField *emailAddressField;
@property (strong, nonatomic) IBOutlet UITextField *userNameField;

@property (strong, nonatomic) IBOutlet UIView *updateView;
@property (strong, nonatomic) IBOutlet UILabel *nameLabel;
@property (strong, nonatomic) IBOutlet UILabel *userNameLabel;
@property (strong, nonatomic) IBOutlet UILabel *emailAddressLabel;

@property (assign, nonatomic) BOOL showBackButton;

- (IBAction)onSubmit:(id)sender;
- (IBAction)onUpdate:(id)sender;

- (void)initView;

@end
