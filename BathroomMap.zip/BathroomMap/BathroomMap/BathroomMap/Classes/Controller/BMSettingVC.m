//
//  BMSettingVC.m
//  BathroomMap
//
//  Created by Xin Liang on 1/24/13.
//  Copyright (c) 2013 BLS Web Services. All rights reserved.
//

#import "BMSettingVC.h"

@interface BMSettingVC ()

@end

@implementation BMSettingVC

@synthesize firstNameField = _firstNameField;
@synthesize lastNameField = _lastNameField;
@synthesize emailAddressField = _emailAddressField;
@synthesize userNameField = _userNameField;

@synthesize nameLabel = _nameLabel;
@synthesize emailAddressLabel = _emailAddressLabel;
@synthesize userNameLabel = _userNameLabel;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    // init view
    [self initView];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [self showTitle:@"Setting"];
    
    if (self.showBackButton)
        [self showLeftButtonWithImage:@"BackButton" andSelector:@selector(onBack)];
}

- (void)initView
{
    _firstNameField.leftView = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, 10, 20)] autorelease];
    _firstNameField.leftViewMode = UITextFieldViewModeAlways;
    _firstNameField.rightView = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, 10, 20)] autorelease];
    _firstNameField.rightViewMode = UITextFieldViewModeAlways;
    
    _lastNameField.leftView = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, 10, 20)] autorelease];
    _lastNameField.leftViewMode = UITextFieldViewModeAlways;
    _lastNameField.rightView = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, 10, 20)] autorelease];
    _lastNameField.rightViewMode = UITextFieldViewModeAlways;
    
    _emailAddressField.leftView = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, 10, 20)] autorelease];
    _emailAddressField.leftViewMode = UITextFieldViewModeAlways;
    _emailAddressField.rightView = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, 10, 20)] autorelease];
    _emailAddressField.rightViewMode = UITextFieldViewModeAlways;
    
    _userNameField.leftView = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, 10, 20)] autorelease];
    _userNameField.leftViewMode = UITextFieldViewModeAlways;
    _userNameField.rightView = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, 10, 20)] autorelease];
    _userNameField.rightViewMode = UITextFieldViewModeAlways;
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    if ([userDefault objectForKey:kFirstName])
        _firstNameField.text = [userDefault objectForKey:kFirstName];
    if ([userDefault objectForKey:kLastName])
        _lastNameField.text = [userDefault objectForKey:kLastName];
    if ([userDefault objectForKey:kEmailAddress])
        _emailAddressField.text = [userDefault objectForKey:kEmailAddress];
    if ([userDefault objectForKey:kUserName])
        _userNameField.text = [userDefault objectForKey:kUserName];
    
    if ([userDefault objectForKey:kFirstName] && [userDefault objectForKey:kLastName])
        _nameLabel.text = [NSString stringWithFormat:@"Name : %@ %@", _firstNameField.text, _lastNameField.text];
    if ([userDefault objectForKey:kEmailAddress])
        _emailAddressLabel.text = [NSString stringWithFormat:@"Email Address : %@", _emailAddressField.text];
    if ([userDefault objectForKey:kUserName])
        _userNameLabel.text = [NSString stringWithFormat:@"User Name : %@", _userNameField.text];
    
    if (![userDefault objectForKey:kFirstName])
        self.updateView.alpha = 0.0;
}

- (void)onBack
{
    [self.navigationController dismissModalViewControllerAnimated:YES];
}

#pragma mark - IBAction
- (IBAction)onSubmit:(id)sender
{
    [_firstNameField resignFirstResponder];
    [_lastNameField resignFirstResponder];
    [_emailAddressField resignFirstResponder];
    [_userNameField resignFirstResponder];
    
    [UIView animateWithDuration:0.3 animations:^{
        CGRect rect;
        rect = self.view.frame;
        rect.origin.y = 0;
        self.view.frame = rect;
    }];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    [userDefault setObject:_firstNameField.text forKey:kFirstName];
    [userDefault setObject:_lastNameField.text forKey:kLastName];
    [userDefault setObject:_emailAddressField.text forKey:kEmailAddress];
    [userDefault setObject:_userNameField.text forKey:kUserName];
    
    [userDefault synchronize];
    
    if ([userDefault objectForKey:kFirstName] && [userDefault objectForKey:kLastName])
        _nameLabel.text = [NSString stringWithFormat:@"Name : %@ %@", _firstNameField.text, _lastNameField.text];
    if ([userDefault objectForKey:kEmailAddress])
        _emailAddressLabel.text = [NSString stringWithFormat:@"Email Address : %@", _emailAddressField.text];
    if ([userDefault objectForKey:kUserName])
        _userNameLabel.text = [NSString stringWithFormat:@"User Name : %@", _userNameField.text];
    
    [UIView animateWithDuration:0.3 animations:^
     {
         self.updateView.alpha = 1.0;
     }];
}

- (IBAction)onUpdate:(id)sender
{
    [UIView animateWithDuration:0.3 animations:^
     {
         self.updateView.alpha = 0.0;
     }];
}

#pragma mark - UITextFieldDelegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [UIView animateWithDuration:0.3 animations:^{
        CGRect rect;
        rect = self.view.frame;
        rect.origin.y = 0;
        self.view.frame = rect;
    }];
    
    [textField resignFirstResponder];
    
    return YES;
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if (textField == _firstNameField || textField == _lastNameField)
        return YES;
    
    [UIView animateWithDuration:0.3 animations:^{
        CGRect rect;
        rect = self.view.frame;
        if (rect.origin.y != 0)
            return;
        rect.origin.y = -120;
        self.view.frame = rect;
    }];
    
    return YES;
}

@end
