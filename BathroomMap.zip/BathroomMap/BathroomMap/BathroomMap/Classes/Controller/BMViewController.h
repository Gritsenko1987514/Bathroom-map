//
//  BMViewController.h
//  BathroomMap
//
//  Created by Xin Liang on 1/23/13.
//  Copyright (c) 2013 BLS Web Services. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BMViewController : UIViewController

@property (nonatomic, assign) IBOutlet UIImageView *activityView;       //  loading wheel
@property (nonatomic, assign) IBOutlet UILabel *progressLabel;          //  loading progress label
@property (nonatomic, assign) IBOutlet UIButton *findBathroomButton;    //  Find a Bathroom button
@property (nonatomic, assign) IBOutlet UIButton *settingButton;         //  App Setting button
@property (nonatomic, assign) IBOutlet UIButton *exitButton;            //  Exit button
@property (nonatomic, assign) IBOutlet UIButton *reloadButton;          //  reload button

- (IBAction)onFindBathroom:(id)sender;
- (IBAction)onAppSetting:(id)sender;
- (IBAction)onExit:(id)sender;
- (IBAction)onReload:(id)sender;

@end
