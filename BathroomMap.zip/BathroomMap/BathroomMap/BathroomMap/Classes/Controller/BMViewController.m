//
//  BMViewController.m
//  BathroomMap
//
//  Created by Xin Liang on 1/23/13.
//  Copyright (c) 2013 BLS Web Services. All rights reserved.
//

#import "BMViewController.h"

#import "BMAppDelegate.h"

#import "BMAPI.h"

#import "BMConstants.h"

#import "BMUtility.h"

#import "BMLocation.h"

#import "BMMapVC.h"

#import "BMNavigationBar.h"

#import "BMRootVC.h"

#import "BMListVC.h"

#import "BMNearmeVC.h"

#import "BMSettingVC.h"

@interface BMViewController ()

- (void)configureAppHirache;

- (void)loadingData;

@end

@implementation BMViewController

@synthesize activityView = _activityView;
@synthesize progressLabel = _progressLabel;
@synthesize findBathroomButton = _findBathroomButton;
@synthesize settingButton = _settingButton;
@synthesize exitButton = _exitButton;

#pragma mark - Action

- (IBAction)onReload:(id)sender
{
    //  reload data from the server
    [self loadingData];
}

- (IBAction)onFindBathroom:(id)sender
{
    //  configure view hirache
    [self configureAppHirache];
}

- (IBAction)onAppSetting:(id)sender
{
    BMSettingVC *settingVC = [[BMSettingVC alloc] init];
    settingVC.showBackButton = YES;
    UINavigationController *settingNavigationController = [BMNavigationBar navigationControllerWithRootViewController:settingVC];
    settingNavigationController.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    settingNavigationController.view.backgroundColor = [UIColor whiteColor];
    [self presentModalViewController:settingNavigationController animated:YES];
    [settingVC release];
}

- (IBAction)onExit:(id)sender
{
    exit(0);
}

- (void)dealloc
{
    
    [super dealloc];
}

#pragma mark - Private

//  @summary: configure app hirache
- (void)configureAppHirache
{
    AppDelegate.tabbarController = [[[CustomTabbar alloc] init] autorelease];
    AppDelegate.tabbarController.delegate = AppDelegate;
    AppDelegate.tabbarController.customDelegate = AppDelegate;
    
    AppDelegate.nearmeVC = [[BMNearmeVC alloc] initWithNibName:@"BMNearmeVC" bundle:nil];
    //AppDelegate.nearmeVC = [[BMMapVC alloc] initWithNibName:@"BMMapVC" bundle:nil];
    UINavigationController *nearmeNavigationController = [BMNavigationBar navigationControllerWithRootViewController:AppDelegate.nearmeVC];
    
    AppDelegate.mapVC = [[BMMapVC alloc] initWithNibName:@"BMMapVC"
                                                  bundle:nil];
    UINavigationController *mapNavigationController = [BMNavigationBar navigationControllerWithRootViewController:AppDelegate.mapVC];
    
    AppDelegate.listVC = [[BMListVC alloc] initWithNibName:@"BMListVC"
                                                    bundle:nil];
    UINavigationController *listNavigationController = [BMNavigationBar navigationControllerWithRootViewController:AppDelegate.listVC];
    
    AppDelegate.settingVC = [[BMSettingVC alloc] initWithNibName:@"BMSettingVC"
                                                          bundle:nil];
    UINavigationController *settingNavigationController = [BMNavigationBar navigationControllerWithRootViewController:AppDelegate.settingVC];
    
    AppDelegate.tabbarController.viewControllers = [NSArray arrayWithObjects:nearmeNavigationController,
                                                    mapNavigationController,
                                                    listNavigationController,
                                                    settingNavigationController,
                                                    nil];
    AppDelegate.rootVC = [[BMRootVC alloc] initWithNibName:@"BMRootVC" bundle:nil];
    [AppDelegate.rootVC addContentViewController:AppDelegate.tabbarController];
    AppDelegate.window.rootViewController = AppDelegate.rootVC;
}

//  @summary: loading data for this app
- (void)loadingData
{
    //  hide menu buttons while loading
    _findBathroomButton.alpha = 0;
    _settingButton.alpha = 0;
    _exitButton.alpha = 0;
    
    //  show loading part while loading
    _activityView.alpha = 1;
    _progressLabel.alpha = 1;
    
    //  loading data for this app
    int64_t delayInSeconds = 1;
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        
        //  loading all locations from the sever
        NSArray *locationArray = [[BMAPI sharedInstance] getLocations];
        
        if (!locationArray)
        {
            [UIView animateWithDuration:0.5 animations:^{
                //  show menu buttons
                _findBathroomButton.alpha = 0;
                _settingButton.alpha = 0;
                _exitButton.alpha = 0;
                _reloadButton.alpha = 1;
                
                //  hide loading part
                _activityView.alpha = 0;
                _progressLabel.alpha = 0;
            }];
            
            UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"BathroomMap"
                                                             message:@"Couldn't get location data"
                                                            delegate:nil
                                                   cancelButtonTitle:@"Ok"
                                                   otherButtonTitles:nil, nil] autorelease];
            [alert show];
            
            return;
        }
        
        if (locationArray && locationArray.count == 0)
        {
            [UIView animateWithDuration:0.5 animations:^{
                //  show menu buttons
                _findBathroomButton.alpha = 0;
                _settingButton.alpha = 0;
                _exitButton.alpha = 0;
                _reloadButton.alpha = 1;
                
                //  hide loading part
                _activityView.alpha = 0;
                _progressLabel.alpha = 0;
            }];
            
            UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"BathroomMap"
                                                             message:@"Couldn't get location data"
                                                            delegate:nil
                                                   cancelButtonTitle:@"Ok"
                                                   otherButtonTitles:nil, nil] autorelease];
            [alert show];
            
            return;
        }
        
        //  store loaded locations to AppDelegate
        AppDelegate.locationArray = [[locationArray mutableCopy] autorelease];
        
        [UIView animateWithDuration:0.5 animations:^{
            //  show menu buttons
            _findBathroomButton.alpha = 1;
            _settingButton.alpha = 1;
            _exitButton.alpha = 1;
            _reloadButton.alpha = 0;
            
            //  hide loading part
            _activityView.alpha = 0;
            _progressLabel.alpha = 0;
        }];
    });
}

#pragma mark - View LifeCycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    //  loading data from the server
    [self loadingData];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
//    self.navigationController.navigationBarHidden = YES;
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
//    self.navigationController.navigationBarHidden = NO;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
