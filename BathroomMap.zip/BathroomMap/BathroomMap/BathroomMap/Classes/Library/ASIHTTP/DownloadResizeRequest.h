//
//  DownloadResizeRequest.h
//  BLS Web Services
//
//  Created by Xin Liang
//  Copyright 2010 
//

#import <Foundation/Foundation.h>
#import "ASIHTTPRequest.h"

@interface DownloadResizeRequest : ASIHTTPRequest
{
	NSString *thumbDestinationPath;
	CGSize maxSize;
}

@property (nonatomic, retain) NSString *thumbDestinationPath;
@property (nonatomic, readwrite) CGSize maxSize;

@end
