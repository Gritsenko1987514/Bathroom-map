//
//  BMCalloutAnnotation.m
//  BathroomMap
//
//  Created by Xin Liang on 1/30/13.
//  Copyright (c) 2013 BLS Web Services. All rights reserved.
//

#import "BMCalloutAnnotation.h"

@implementation BMCalloutAnnotation

@synthesize coordinate = _coordinate;
@synthesize title = _title;
@synthesize subtitle = _subtitle;
@synthesize location = _location;

- (id)initWithCoordinate:(CLLocationCoordinate2D)coordinate
                   title:(NSString *)title
                subtitle:(NSString *)subtitle
                location:(BMLocation *)location
{
    
    self = [super init];
    
    if (self)
    {
        _coordinate = coordinate;
        _title = [title copy];
        _subtitle = [subtitle copy];
        self.location = location;
    }
    
    return self;
}

- (void)dealloc {
    
    [_title release]; _title = nil;
    [_subtitle release]; _subtitle = nil;
    [_location release]; _location = nil;
    
    [super dealloc];
}


#pragma mark - MKAnnotation Implements

- (void)setCoordinate:(CLLocationCoordinate2D)newCoordinate NS_AVAILABLE(NA, 4_0)
{
    
}

@end
