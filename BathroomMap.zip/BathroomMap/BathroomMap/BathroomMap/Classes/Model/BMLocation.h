//
//  BMLocation.h
//  BathroomMap
//
//  Created by Xin Liang on 1/23/13.
//  Copyright (c) 2013 BLS Web Services. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BMConstants.h"

@interface BMFeedback : NSObject

@property (nonatomic, assign) NSInteger feedbackId; //  id of this feedback
@property (nonatomic, strong) NSString *user;   //  name of a person gave this rating
@property (nonatomic, strong) NSString *email;  //  email of a person gave this rating related with the user name
@property (nonatomic, strong) NSDate *date;   //  date gave this rating
@property (nonatomic, strong) NSString *feedback;   //  feedback rater gave
@property (nonatomic, assign) RateType rateType;    //  rating type
@property (nonatomic, assign) NSInteger locationId; //  locaiton_id
@property (nonatomic, assign) NSInteger publish;    //  publish
@property (nonatomic, assign) NSTimeInterval createdAt;     //  created_at
@property (nonatomic, assign) NSTimeInterval updatedAt;     //  updated_at

- (id)initWithDictionary:(NSDictionary *)dictionary;

@end

@interface BMLocation : NSObject

@property (nonatomic, assign) NSInteger locationId; //  id of this location
@property (nonatomic, strong) NSString *name;       //  location name
@property (nonatomic, assign) double latitude;      //  latitude of this location
@property (nonatomic, assign) double longitude;     //  longitude of this location
@property (nonatomic, assign) LocationCategory category;    //  location type
@property (nonatomic, assign) float distance;       //  distance
@property (nonatomic, assign) RateType rateType;    //  rate type
@property (nonatomic, strong) NSString *locationDescription;    //  descriptions of this location
@property (nonatomic, strong) NSString *locationDescriptionLink;    //  description link for more description of this location
@property (nonatomic, strong) NSString *location;    //  address of this location
@property (nonatomic, strong) NSString *city;        // city
@property (nonatomic, strong) NSString *state;          //  state
@property (nonatomic, strong) NSString *street;         //  street
@property (nonatomic, strong) NSString *zipcode;        //  zipcode
@property (nonatomic, strong) NSString *phone;          //  phone
@property (nonatomic, strong) NSString *website;        //  website
@property (nonatomic, assign) NSTimeInterval createdAt; //  created_at
@property (nonatomic, assign) NSTimeInterval updatedAt; //  updated_at
@property (nonatomic, strong) NSMutableArray *feedbackArray;      //  rating array for this location

- (id)initWithDictionary:(NSDictionary *)dictionary;

@end
