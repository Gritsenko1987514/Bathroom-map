//
//  BMLocation.m
//  BathroomMap
//
//  Created by Xin Liang on 1/23/13.
//  Copyright (c) 2013 BLS Web Services. All rights reserved.
//

#import "BMLocation.h"
#import "BMConstants.h"
#import "BMUtility.h"

@implementation BMFeedback

@synthesize user = _user;
@synthesize email = _email;
@synthesize date = _date;
@synthesize feedbackId = _feedbackId;
@synthesize locationId = _locationId;
@synthesize publish = _publish;
@synthesize createdAt = _createdAt;
@synthesize updatedAt = _updatedAt;
@synthesize feedback = _feedback;
@synthesize rateType = _rateType;

- (id)initWithDictionary:(NSDictionary *)dictionary
{
    if (!dictionary)
        return nil;
    
    if (![dictionary isKindOfClass:[NSDictionary class]])
        return nil;
    
    self = [super init];
    if (self) {
        id rating = [dictionary objectForKey:kStringRating];
        if (rating && rating != [NSNull null])
        {
            switch ([rating intValue]) {
                case 1:
                    self.rateType = RateTypeBad;
                    break;
                    
                case 2:
                    self.rateType = RateTypeNormal;
                    break;
                    
                case 3:
                    self.rateType = RateTypeGood;
                    break;
                    
                default:
                    break;
            }
        }
        
        id feedback_id = [dictionary objectForKey:kStringId];
        if (feedback_id && feedback_id != [NSNull null])
            self.feedbackId = [feedback_id intValue];
        
        id created_at = [dictionary objectForKey:kStringCreatedAt];
        if (created_at && created_at != [NSNull null])
            self.createdAt = [created_at doubleValue];
        
        self.feedback = [dictionary objectForKey:kStringFeedback];
        
        id location_id = [dictionary objectForKey:kStringLocationId];
        if (location_id && location_id != [NSNull null])
            self.locationId = [location_id intValue];
        
        id publish = [dictionary objectForKey:kStringPublish];
        if (publish && publish != [NSNull null])
            self.publish = [publish intValue];
        
        id updated_at = [dictionary objectForKey:kStringUpdatedAt];
        if (updated_at && updated_at != [NSNull null])
            self.updatedAt = [updated_at doubleValue];
        
        self.user = [dictionary objectForKey:kStringUser];
        self.email = [dictionary objectForKey:kStringEmail];
    }
    
    return self;
}

- (void)dealloc
{
    [_user release];
    [_email release];
    [_date release];
    [_feedback release];
    
    [super dealloc];
}

@end

@implementation BMLocation

@synthesize locationId = _locationId;
@synthesize name = _name;
@synthesize latitude = _latitude;
@synthesize longitude = _longitude;
@synthesize category = _category;
@synthesize distance = _distance;
@synthesize rateType = _rateType;
@synthesize locationDescription = _locationDescription;
@synthesize locationDescriptionLink = _locationDescriptionLink;
@synthesize location = _location;
@synthesize city = _city;
@synthesize state = _state;
@synthesize street = _street;
@synthesize zipcode = _zipcode;
@synthesize phone = _phone;
@synthesize createdAt = _createdAt;
@synthesize updatedAt = _updatedAt;
@synthesize website = _website;
@synthesize feedbackArray = _feedbackArray;

- (id)initWithDictionary:(NSDictionary *)dictionary
{
    if (!dictionary)
        return nil;
    
    if (![dictionary isKindOfClass:[NSDictionary class]])
        return nil;
    
    self = [super init];
    if (self) {
        id location_id = [dictionary objectForKey:kStringId];
        if (location_id && location_id != [NSNull null])
            self.locationId = [location_id intValue];
        
        self.name = [dictionary objectForKey:kStringName];
        self.website = [dictionary objectForKey:kStringWebsite];
        
        id category = [dictionary objectForKey:kStringCategory];
        if (category)
        {
            //jin modify
            id c_id = [category objectForKey:kStringId];
            if (c_id) {
                switch ([c_id intValue]) {
                    case 1:
                        self.category = LocationCategoryAirport;
                        break;
                        
                    case 2:
                        self.category = LocationCategoryTrainStation;
                        break;
                        
                    case 3:
                        self.category = LocationCategoryCoffeehouse;
                        break;
                        
                    case 4:
                        self.category = LocationCategoryHotel;
                        break;
                        
                    case 5:
                        self.category = LocationCategoryResort;
                        break;
                        
                    case 6:
                        self.category = LocationCategoryMovieTheater;
                        break;
                        
                    case 7:
                        self.category = LocationCategoryDepartmentStore;
                        break;
                        
                    case 8:
                        self.category = LocationCategoryFurnitureStore;
                        break;
                        
                    case 9:
                        self.category = LocationCategoryBookStore;
                        break;
                        
                    case 10:
                        self.category = LocationCategoryGroceryStore;
                        break;
                        
                    case 11:
                        self.category = LocationCategoryRestaurant;
                        break;
                        
                    case 12:
                        self.category = LocationCategoryTacoTime;
                        break;
                        
                    default:
                        break;
                }
            }
            
        }
        
        id latitude = [dictionary objectForKey:kStringLatitude];
        if (latitude && latitude != [NSNull null])
            self.latitude = [latitude doubleValue];
        
        id longitude = [dictionary objectForKey:kStringLongitude];
        if (longitude && longitude != [NSNull null])
            self.longitude = [longitude doubleValue];
        
        self.phone = [dictionary objectForKey:kStringPhone];
        
        self.locationDescription = [dictionary objectForKey:kStringDescription];
        
        self.state = [dictionary objectForKey:kStringState];
        
        self.city = [dictionary objectForKey:kStringCity];
        
        self.street = [dictionary objectForKey:kStringStreet];
        
        self.zipcode = [dictionary objectForKey:kStringZipcode];
        
        self.location = [NSString stringWithFormat:@"%@, %@, %@ %@", _street, _city, _state, _zipcode];
        
        id created_at = [dictionary objectForKey:kStringCreatedAt];
        if (created_at && created_at != [NSNull null])
            self.createdAt = [created_at doubleValue];
        
        id updated_at = [dictionary objectForKey:kStringUpdatedAt];
        if (updated_at && updated_at != [NSNull null])
            self.updatedAt = [updated_at doubleValue];
        
        id feedbackArray = [dictionary objectForKey:kStringFeedbacks];
        if (feedbackArray && [feedbackArray isKindOfClass:[NSArray class]])
        {
            _feedbackArray = [[NSMutableArray alloc] init];
            for (NSDictionary *feedbackDictionary in feedbackArray) {
                BMFeedback *feedback = [[[BMFeedback alloc] initWithDictionary:feedbackDictionary] autorelease];
                [_feedbackArray addObject:feedback];
            }
        }
    }
    return self;
}

- (void)dealloc
{
    [_name release];
    [_location release];
    [_locationDescription release];
    [_locationDescriptionLink release];
    [_state release];
    [_city release];
    [_street release];
    [_zipcode release];
    [_phone release];
    [_feedbackArray release];
    [_website release];
    [super dealloc];
}

@end
