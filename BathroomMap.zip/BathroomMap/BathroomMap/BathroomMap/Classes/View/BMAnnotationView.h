//
//  BMAnnotationView.h
//  BathroomMap
//
//  Created by Xin Liang on 1/30/13.
//  Copyright (c) 2013 BLS Web Services. All rights reserved.
//

#import <MapKit/MapKit.h>
#import "BMCalloutAnnotationView.h"

@class BMMapVC;

@interface BMAnnotationView : MKAnnotationView <BMCalloutAnnotationViewDelegate>

@property (nonatomic, strong) BMCalloutAnnotationView *calloutView;

@property (nonatomic, assign) BMMapVC *mapViewController;   //  map view controller includes this annotation view

@property (nonatomic, assign) BOOL isCalloutVisible;

@property (nonatomic, assign) BOOL hitTestBufferForDirectionButton;

@property (nonatomic, assign) BOOL hitTestBufferForDetailButton;

- (void)setSelected:(BOOL)selected animated:(BOOL)animated;
- (void)animateCalloutAppearance;

@end
