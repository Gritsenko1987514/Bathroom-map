//
//  BMAnnotationView.m
//  BathroomMap
//
//  Created by Xin Liang on 1/30/13.
//  Copyright (c) 2013 BLS Web Services. All rights reserved.
//

#import "BMAnnotationView.h"
#import "BMCalloutAnnotationView.h"
#import "BMAnnotation.h"
#import "BMMapVC.h"
#import "BMConstants.h"
#import "BMAppDelegate.h"
#import "BMUtility.h"

@implementation BMAnnotationView

@synthesize calloutView = _calloutView;
@synthesize mapViewController = _mapViewController;
@synthesize isCalloutVisible = _isCalloutVisible;
@synthesize hitTestBufferForDirectionButton = _hitTestBufferForDirectionButton;
@synthesize hitTestBufferForDetailButton = _hitTestBufferForDetailButton;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)dealloc
{
    [_calloutView release];
    _mapViewController = nil;
    [super dealloc];
}

- (void)setSelected:(BOOL)selected
           animated:(BOOL)animated
{
    if(selected)
    {
        _isCalloutVisible = YES;
        _hitTestBufferForDetailButton = NO;
        _hitTestBufferForDirectionButton = NO;
        //Add your custom view to self...
        NSString *reuseIdentifier = nil;
        _calloutView = [[BMCalloutAnnotationView alloc] initWithAnnotation:self.annotation reuseIdentifier:reuseIdentifier];
        _calloutView.delegate = (id <BMCalloutAnnotationViewDelegate>)_mapViewController;
        _calloutView.annotationView = self;
        CGRect rect = _calloutView.frame;
        rect.origin.x = -115;
        rect.origin.y = -165;
        [_calloutView setFrame:rect];
        [_calloutView sizeToFit];
        
        [self animateCalloutAppearance];
        [self addSubview:_calloutView];
        
        [super setSelected:selected
                  animated:animated];
    }
    else
    {
        //Remove your custom view...
        _isCalloutVisible = NO;
        [_calloutView removeFromSuperview];
    }
}

- (UIView *)hitTest:(CGPoint)point
          withEvent:(UIEvent *)event
{
    if (_isCalloutVisible) {
        CGPoint hitPoint = [self convertPoint:point toView:_calloutView.directionButton];
        if ([_calloutView.directionButton pointInside:hitPoint withEvent:event]) {
            if (!_hitTestBufferForDirectionButton)
            {
                _hitTestBufferForDirectionButton = YES;
                [_calloutView onDirection:nil];
            }
            return [_calloutView.directionButton hitTest:point withEvent:event];
        } else {
            _hitTestBufferForDirectionButton = NO;
        }
        
        hitPoint = [self convertPoint:point toView:_calloutView.detailButton];
        if ([_calloutView.detailButton pointInside:hitPoint withEvent:event]) {
            if (!_hitTestBufferForDetailButton)
            {
                _hitTestBufferForDetailButton = YES;
                [self setSelected:NO animated:YES];
                int64_t delayInSeconds = 1;
                dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
                dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
                    [_calloutView onDetail:nil];
                });
            }
            return [_calloutView.detailButton hitTest:point withEvent:event];
        } else {
            _hitTestBufferForDetailButton = NO;
        }
    }
    
    return [super hitTest:point withEvent:event];
}

- (void)didAddSubview:(UIView *)subview{
    if ([[[subview class] description] isEqualToString:@"UICalloutView"]) {
        //  when adding custom callout view to this pin, removing default UICalloutView from this view
        for (UIView *subsubView in subview.subviews) {
            if ([subsubView class] == [UIImageView class]) {
                UIImageView *imageView = ((UIImageView *)subsubView);
                [imageView removeFromSuperview];
            }else if ([subsubView class] == [UILabel class]) {
                UILabel *labelView = ((UILabel *)subsubView);
                [labelView removeFromSuperview];
            }
        }
    }
}

//  @summary: apply popup animation effect for custom callout view
- (void)animateCalloutAppearance {
    CGFloat scale = 0.001f;
    _calloutView.transform = CGAffineTransformMake(scale, 0.0f, 0.0f, scale, 0, -50);
    
    [UIView animateWithDuration:0.15 delay:0 options:UIViewAnimationCurveEaseOut animations:^{
        CGFloat scale = 1.1f;
        _calloutView.transform = CGAffineTransformMake(scale, 0.0f, 0.0f, scale, 0, 2);
    } completion:^(BOOL finished) {
        [UIView animateWithDuration:0.1 delay:0 options:UIViewAnimationCurveEaseInOut animations:^{
            CGFloat scale = 0.95;
            _calloutView.transform = CGAffineTransformMake(scale, 0.0f, 0.0f, scale, 0, -2);
        } completion:^(BOOL finished) {
            [UIView animateWithDuration:0.075 delay:0 options:UIViewAnimationCurveEaseInOut animations:^{
                CGFloat scale = 1.0;
                _calloutView.transform = CGAffineTransformMake(scale, 0.0f, 0.0f, scale, 0, 0);
            } completion:nil];
        }];
    }];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
