//
//  BMCalloutAnnotationView.h
//  BathroomMap
//
//  Created by Xin Liang on 1/30/13.
//  Copyright (c) 2013 BLS Web Services. All rights reserved.
//

#import <MapKit/MapKit.h>

@protocol BMCalloutAnnotationViewDelegate;

@class BMAnnotation, BMLocation, BMCalloutAnnotation, BMAnnotationView;

@interface BMCalloutAnnotationView : MKAnnotationView

@property (nonatomic, assign) IBOutlet UIView *rootView;

@property (nonatomic, assign) IBOutlet UILabel *titleLabel;

@property (nonatomic, assign) IBOutlet UILabel *typeLabel;

@property (nonatomic, assign) IBOutlet UIImageView *ratingView;

@property (nonatomic, assign) IBOutlet UILabel *locationLabel;

@property (nonatomic, assign) IBOutlet UIButton *directionButton;

@property (nonatomic, assign) IBOutlet UIButton *detailButton;

@property (nonatomic, strong) BMCalloutAnnotation *calloutAnnotation; //  annotation associated with this callout view

@property (nonatomic, assign) id <BMCalloutAnnotationViewDelegate> delegate;

@property (nonatomic, assign) BMAnnotationView *annotationView;

- (IBAction)onDirection:(id)sender;

- (IBAction)onDetail:(id)sender;

@end

@protocol BMCalloutAnnotationViewDelegate <NSObject>

@optional

//  @summary: user did selected direction button in this callout view
- (void)didSelectDirection:(BMLocation *)location;

//  @summary: user did select detail butotn in this callout view
- (void)didSelectDetail:(BMLocation *)location;

@end
