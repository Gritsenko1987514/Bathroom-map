//
//  BMCalloutAnnotationView.m
//  BathroomMap
//
//  Created by Xin Liang on 1/30/13.
//  Copyright (c) 2013 BLS Web Services. All rights reserved.
//

#import "BMCalloutAnnotationView.h"
#import "BMAnnotation.h"
#import "BMUtility.h"
#import "BMConstants.h"
#import "BMLocation.h"
#import "BMCalloutAnnotation.h"
#import "BMAppDelegate.h"
#import "BMListVC.h"
#import "BMAnnotationView.h"

@interface BMCalloutAnnotationView ()

@end

@implementation BMCalloutAnnotationView

@synthesize annotationView = _annotationView;

@synthesize calloutAnnotation = _calloutAnnotation;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        [[NSBundle mainBundle] loadNibNamed:@"BMCalloutAnnotationView" owner:self options:nil];
        [self addSubview:_rootView];
        self.frame = _rootView.frame;
    }
    return self;
}

- (id)initWithAnnotation:(id<MKAnnotation>)annotation
         reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithAnnotation:annotation
                     reuseIdentifier:reuseIdentifier];
    if (self) {
        /*********************************************************
         * Initialization code
         *********************************************************/
        //  init this callout view from nib file
        [[NSBundle mainBundle] loadNibNamed:@"BMCalloutAnnotationView"
                                      owner:self
                                    options:nil];
        [self addSubview:_rootView];
        self.frame = _rootView.frame;
        
        /*****************************************************************************
         * init annotation for this callout view
         *****************************************************************************/
        BMAnnotation *bmAnnotation = (BMAnnotation *)annotation;
        self.annotation = annotation;
        
        /********************************************************************************
         * display informations for this callout view from settlement the annotation
         ********************************************************************************/
        //  title of location
        _titleLabel.text = bmAnnotation.location.name;
        
//        LocationCategoryAirport = 1,
//        LocationCategoryTrainStation,
//        LocationCategoryCoffeehouse,
//        LocationCategoryHotel,
//        LocationCategoryResort,
//        LocationCategoryMovieTheater,
//        LocationCategoryDepartmentStore,
//        LocationCategoryFurnitureStore,
//        LocationCategoryBookStore,
//        LocationCategoryGroceryStore,
//        LocationCategoryRestaurant,
//        LocationCategoryTacoTime
        
        //  type of location
        switch (bmAnnotation.location.category) {
            case LocationCategoryAirport:
                _typeLabel.text = kStringAirplane;
                break;
            case LocationCategoryTrainStation:
                _typeLabel.text = kStringTrainStation;
                break;
            case LocationCategoryCoffeehouse:
                _typeLabel.text = kStringCoffee;
                break;
            case LocationCategoryHotel:
                _typeLabel.text = kStringHotel;
                break;
            case LocationCategoryResort:
                _typeLabel.text = kStringResort;
                break;
            case LocationCategoryMovieTheater:
                _typeLabel.text = kStringMovieTheater;
                break;
            case LocationCategoryDepartmentStore:
                _typeLabel.text = kStringDepartment;
                break;
            case LocationCategoryFurnitureStore:
                _typeLabel.text = kStringFurniture;
                break;
            case LocationCategoryBookStore:
                _typeLabel.text = kStringBookStore;
                break;
            case LocationCategoryGroceryStore:
                _typeLabel.text = kStringGrocery;
                break;
            case LocationCategoryRestaurant:
                _typeLabel.text = kStringRestaurant;
                break;
            case LocationCategoryTacoTime:
                _typeLabel.text = kStringTacoTime;
                break;
            default:
                break;
        }
        
        //  rating of location
        switch (bmAnnotation.location.rateType) {
            case RateTypeBad:
                _ratingView.image = [UIImage imageNamed:@"RatingBad"];
                break;
            case RateTypeNormal:
                _ratingView.image = [UIImage imageNamed:@"RatingNormal"];
                break;
            case RateTypeGood:
                _ratingView.image = [UIImage imageNamed:@"RatingSmile"];
                break;
                
            default:
                break;
        }
        
        //  location of location
        _locationLabel.text = bmAnnotation.location.location;
    }
    return self;
}

- (void)dealloc
{
    [_calloutAnnotation release];
    [super dealloc];
}

#pragma mark - Action

- (IBAction)onDirection:(id)sender
{
//    [_directionButton setImage:[UIImage imageNamed:@"Ads"]
//                      forState:UIControlStateNormal];
    if (_delegate
        && [_delegate conformsToProtocol:@protocol(BMCalloutAnnotationViewDelegate)]
        && [_delegate respondsToSelector:@selector(didSelectDirection:)])
    {
        BMAnnotation *bmAnnotation = (BMAnnotation *)self.annotation;
        [_delegate didSelectDirection:bmAnnotation.location];
    }
}

- (IBAction)onDetail:(id)sender
{
//    [_detailButton setImage:[UIImage imageNamed:@"Ads"]
//                      forState:UIControlStateNormal];
    if (_delegate
        && [_delegate conformsToProtocol:@protocol(BMCalloutAnnotationViewDelegate)]
        && [_delegate respondsToSelector:@selector(didSelectDetail:)])
    {
        BMAnnotation *bmAnnotation = (BMAnnotation *)self.annotation;
        [_delegate didSelectDetail:bmAnnotation.location];
    }
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
