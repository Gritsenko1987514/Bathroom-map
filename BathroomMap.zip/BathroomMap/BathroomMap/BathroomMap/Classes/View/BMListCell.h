//
//  BMListCell.h
//  BathroomMap
//
//  Created by Xin Liang on 1/23/13.
//  Copyright (c) 2013 BLS Web Services. All rights reserved.
//

#import <UIKit/UIKit.h>

@class BMLocation, BMListVC;

@interface BMListCell : UITableViewCell

@property (nonatomic, assign) IBOutlet UIImageView *backgroundImageView;
@property (nonatomic, assign) IBOutlet UILabel *nameLabel;
@property (nonatomic, assign) IBOutlet UILabel *typeLabel;
@property (nonatomic, assign) IBOutlet UILabel *distanceLabel;
@property (nonatomic, assign) IBOutlet UIImageView *ratingView;
@property (nonatomic, strong) BMLocation *location;                         //  information of this location
@property (nonatomic, assign) BMListVC *viewController;                     //  parent view controller of this cell

@end
