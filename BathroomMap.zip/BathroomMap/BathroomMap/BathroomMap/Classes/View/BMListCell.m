//
//  BMListCell.m
//  BathroomMap
//
//  Created by Xin Liang on 1/23/13.
//  Copyright (c) 2013 BLS Web Services. All rights reserved.
//

#import "BMListCell.h"
#import "BMLocation.h"
#import "BMDetailVC.h"
#import "BMListVC.h"

@implementation BMListCell

@synthesize backgroundImageView = _backgroundImageView;
@synthesize nameLabel = _nameLabel;
@synthesize typeLabel = _typeLabel;
@synthesize distanceLabel = _distanceLabel;
@synthesize ratingView = _ratingView;
@synthesize location = _location;
@synthesize viewController = _viewController;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)dealloc
{
    [_location release];
    [super dealloc];
}

- (void)setFrame:(CGRect)frame
{
    [super setFrame:frame];
    
    //  location name label
    self.nameLabel.text = _location.name;
    
    //  location type label
    switch (_location.category) {
        case LocationCategoryAirport:
            _typeLabel.text = kStringAirplane;
            break;
//        case LocationCategoryCampsite:
//            _typeLabel.text = kStringCampsite;
//            break;
        case LocationCategoryCoffeehouse:
            _typeLabel.text = kStringCoffee;
            break;
//        case LocationCategoryGasStation:
//            _typeLabel.text = kStringGasStation;
//            break;
        case LocationCategoryHotel:
            _typeLabel.text = kStringHotel;
            break;
//        case LocationCategoryParkingArea:
//            _typeLabel.text = kStringParkingArea;
//            break;
        case LocationCategoryRestaurant:
            _typeLabel.text = kStringRestaurant;
            break;
            
        case LocationCategoryBookStore:
            _typeLabel.text = kStringBookStore;
            break;
            
        case LocationCategoryDepartmentStore:
            _typeLabel.text = kStringDepartment;
            break;
            
        case LocationCategoryFurnitureStore:
            _typeLabel.text = kStringFurniture;
            break;
            
        case LocationCategoryGroceryStore:
            _typeLabel.text = kStringGrocery;
            break;
            
        case LocationCategoryMovieTheater:
            _typeLabel.text = kStringMovieTheater;
            break;
            
        case LocationCategoryResort:
            _typeLabel.text = kStringResort;
            break;
            
        case LocationCategoryTacoTime:
            _typeLabel.text = kStringTacoTime;
            break;
            
        case LocationCategoryTrainStation:
            _typeLabel.text = kStringTrainStation;
            break;
            
        default:
            break;
    }
    
    //  distance label
    CLLocationCoordinate2D currentlocation;
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    currentlocation.latitude = [[userDefault objectForKey:kCurrentLat] floatValue];
    currentlocation.longitude = [[userDefault objectForKey:kCurrentLon] floatValue];
    BOOL bCurrentLocation = YES;
    if (currentlocation.latitude == 0 && currentlocation.longitude == 0) {
        /*
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"BathroomMap" message:@"Can't get the current location" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
        [alert release];
        */
        bCurrentLocation = NO;
    }
    //currentlocation.latitude = 40.119152;
    //currentlocation.longitude = -74.302606;
    CLLocationCoordinate2D bathroomLocation;
    bathroomLocation.latitude = _location.latitude;
    bathroomLocation.longitude = _location.longitude;
    float distance = [BMUtility calculateDistanceBetweenSource:currentlocation destination:bathroomLocation];
    _distanceLabel.text = [NSString stringWithFormat:@"%.1f miles", distance / 1.6];
    if (bCurrentLocation == NO)
        _distanceLabel.text = @"No Location";
    //  rating
    switch (_location.rateType) {
        case RateTypeBad:
            _ratingView.image = [UIImage imageNamed:@"RatingBad"];
            break;
        case RateTypeNormal:
            _ratingView.image = [UIImage imageNamed:@"RatingNormal"];
            break;
        case RateTypeGood:
            _ratingView.image = [UIImage imageNamed:@"RatingSmile"];
            break;
            
        default:
            break;
    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
    
    //  adjust background image
    if (!selected)
    {
        _backgroundImageView.image = [UIImage imageNamed:@"ListCellBG"];
        return;
    }
    _backgroundImageView.image = [UIImage imageNamed:@"ListCellBG"];
    
    //  go to the detail page of the this location
    BMDetailVC *vc = [[[BMDetailVC alloc] initWithNibName:@"BMDetailVC" bundle:nil] autorelease];
    vc.location = _location;
    vc.listViewController = _viewController;
    [_viewController.navigationController pushViewController:vc animated:YES];
}

@end
