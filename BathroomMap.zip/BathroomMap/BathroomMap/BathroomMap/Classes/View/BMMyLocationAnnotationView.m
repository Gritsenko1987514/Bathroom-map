//
//  BMMyLocationAnnotationView.m
//  BathroomMap
//
//  Created by Xin Liang on 1/31/13.
//  Copyright (c) 2013 BLS Web Services. All rights reserved.
//

#import "BMMyLocationAnnotationView.h"
#import "BMAnnotation.h"

@implementation BMMyLocationAnnotationView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        [[NSBundle mainBundle] loadNibNamed:@"BMMyLocationAnnotationView" owner:self options:nil];
        [self addSubview:_myLocaitonView];
        self.frame = _myLocaitonView.frame;
    }
    return self;
}

- (id)initWithAnnotation:(id<MKAnnotation>)annotation
         reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithAnnotation:annotation
                     reuseIdentifier:reuseIdentifier];
    if (self) {
        /*********************************************************
         * Initialization code
         *********************************************************/
        //  init this view from nib file
        [[NSBundle mainBundle] loadNibNamed:@"BMMyLocationAnnotationView"
                                      owner:self
                                    options:nil];
        [self addSubview:_myLocaitonView];
        self.frame = _myLocaitonView.frame;
        
        /*****************************************************************************
         * init annotation for this callout view
         *****************************************************************************/
        self.annotation = annotation;
    }
    return self;
}

- (void)dealloc
{
    [super dealloc];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
