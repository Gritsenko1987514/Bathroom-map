//
//  SANavigationBar.h
//  CardLust
//
//  Created by XinLiang on 6/7/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BMNavigationBar : UINavigationBar

+ (UINavigationController *)navigationControllerWithRootViewController:(UIViewController *)rootViewController;

@end
