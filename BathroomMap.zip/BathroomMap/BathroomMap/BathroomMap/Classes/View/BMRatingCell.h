//
//  BMRatingCell.h
//  BathroomMap
//
//  Created by Xin Liang on 1/24/13.
//  Copyright (c) 2013 BLS Web Services. All rights reserved.
//

#import <UIKit/UIKit.h>

@class BMFeedback;

@interface BMRatingCell : UITableViewCell

@property (nonatomic, assign) IBOutlet UIImageView *backgroundImageView;
@property (nonatomic, assign) IBOutlet UILabel *nameLabel;
@property (nonatomic, assign) IBOutlet UILabel *dateLabel;
@property (nonatomic, assign) IBOutlet UILabel *feedbackLabel;
@property (nonatomic, assign) IBOutlet UIImageView *ratingView;
@property (nonatomic, assign) IBOutlet UIImageView *separaterView;
@property (nonatomic, strong) BMFeedback *rating;

- (void)configRatingCell;

@end
