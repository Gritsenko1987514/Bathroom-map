//
//  BMRatingCell.m
//  BathroomMap
//
//  Created by Xin Liang on 1/24/13.
//  Copyright (c) 2013 BLS Web Services. All rights reserved.
//

#import "BMRatingCell.h"
#import "BMLocation.h"
#import "BMUtility.h"

@implementation BMRatingCell

@synthesize backgroundImageView = _backgroundImageView;
@synthesize nameLabel = _nameLabel;
@synthesize dateLabel = _dateLabel;
@synthesize feedbackLabel = _feedbackLabel;
@synthesize ratingView = _ratingView;
@synthesize separaterView = _separaterView;
@synthesize rating = _rating;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)dealloc
{
    [_rating release];
    [super dealloc];
}

- (void)setFrame:(CGRect)frame
{
    [super setFrame:frame];
    
}

- (void)configRatingCell
{
    //  configure UI of this cell with rating model
    NSString *feedback = _rating.feedback;
    CGSize constrainSize = CGSizeMake(172, CGFLOAT_MAX);
    CGSize stringSize = [BMUtility sizeOfString:feedback
                             andConstrainedSize:constrainSize
                                    andFontSize:13.0f];
    NSInteger height = stringSize.height;
    CGRect rect = _feedbackLabel.frame;     //  adjust height of feedback label
    rect.size.height = height;
    _feedbackLabel.frame = rect;
    CGPoint centerPoint = _ratingView.center;   //  adjust the center point of rating view
    centerPoint.y = self.center.y;
    _ratingView.center = centerPoint;
    rect = _separaterView.frame;
    rect.origin.y = self.frame.size.height;
    _separaterView.frame = rect;
    
    //  display informations
    _nameLabel.text = _rating.user;
    _feedbackLabel.text = _rating.feedback;
    NSString *dateString = nil;
    NSDateFormatter *dateFormatter = [[[NSDateFormatter alloc] init] autorelease];
    [dateFormatter setDateFormat:@"MMM d, yyyy"];
    NSDate *createdAt = [NSDate dateWithTimeIntervalSince1970:_rating.createdAt];
    dateString = [dateFormatter stringFromDate:createdAt];
    _dateLabel.text = dateString;
    switch (_rating.rateType) {
        case RateTypeBad:
            _ratingView.image = [UIImage imageNamed:@"RatingBad"];
            break;
        case RateTypeNormal:
            _ratingView.image = [UIImage imageNamed:@"RatingNormal"];
            break;
        case RateTypeGood:
            _ratingView.image = [UIImage imageNamed:@"RatingSmile"];
            break;
            
        default:
            break;
    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
