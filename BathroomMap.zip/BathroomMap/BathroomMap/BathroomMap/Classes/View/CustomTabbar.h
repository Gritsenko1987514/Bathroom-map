//
//  CustomTabbar.h
//  Labandme
//
//  Created by Xin Liang
//  Copyright 2012 Labandme.com
//

#import <UIKit/UIKit.h>

@protocol CustomTabDelegate <NSObject>
@required
- (void)didselectTab : (NSInteger)tabIndex;
@optional
- (void)selectCurrentTab;
@end

@interface CustomTabbar : UITabBarController <UIGestureRecognizerDelegate> {
    id<CustomTabDelegate> customDelegate;
}

@property (strong, nonatomic) UIButton *btn1;
@property (strong, nonatomic) UIButton *btn2;
@property (strong, nonatomic) UIButton *btn3;
@property (strong, nonatomic) UIButton *btn4;
@property (strong, nonatomic) UIImageView *backgroundView;
@property (nonatomic, strong) UIImageView *selectionMask;

@property (nonatomic, assign) id<CustomTabDelegate> customDelegate;

-(void) hideTabBar;
-(void) addCustomElements;
-(void) selectTab:(int)tabID;

-(void) hideNewTabBar;
-(void) ShowNewTabBar;
-(void) buttonClicked:(id)sender;
- (void)visibleTab;
- (void)adjustSelectionMaskForIndex:(NSInteger)index;

@end
