//
//  CustomTabbar.m
//  Labandme
//
//  Created by Xin Liang
//  Copyright 2012 Labandme.com
//

#import "CustomTabbar.h"

@implementation CustomTabbar

@synthesize btn1 = _btn1;
@synthesize btn2 = _btn2;
@synthesize btn3 = _btn3;
@synthesize btn4 = _btn4;
@synthesize backgroundView = _backgroundView;
@synthesize customDelegate;
@synthesize selectionMask = _selectionMask;

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self hideTabBar];
	[self addCustomElements];
    self.tabBar.backgroundColor = [UIColor clearColor];
}

- (void)dealloc {
	[_btn1 release];
	[_btn2 release];
    [_btn3 release];
    [_btn4 release];
    [_backgroundView release];
    [_selectionMask release];
	
    [super dealloc];
}

-(void) hideTabBar {
    for(UIView *view in self.view.subviews)
	{
		if([view isKindOfClass:[UITabBar class]])
		{
			view.hidden = YES;
			break;
		}
	}
}

//  @summary: adjust position selection mask along the tab item selection
//  @param: index: tab index selected
- (void)adjustSelectionMaskForIndex:(NSInteger)index
{
    CGRect rect;
    switch (index) {
        case 0:
        {
            rect = self.btn1.frame;
            _selectionMask.frame = rect;
        }
            break;
        case 1:
        {
            rect = self.btn2.frame;
            _selectionMask.frame = rect;
        }
            break;
        case 2:
        {
            rect = self.btn3.frame;
            _selectionMask.frame = rect;
        }
            break;
        case 3:
        {
            rect = self.btn4.frame;
            _selectionMask.frame = rect;
        }
            break;
            
        default:
            break;
    }
}

-(void) addCustomElements {
    // Initialise our two images
	UIImage *btnImageUnselect = nil;
	UIImage *btnImageSelected = nil;
    CGFloat btnY = 380;
    CGFloat btnWidth = 80;
    CGFloat btnHeight = 50;
    
    //  first tab
    btnImageUnselect = [UIImage imageNamed:@"TabbarNearMe"];
    btnImageSelected = [UIImage imageNamed:@"TabbarNearMe"];
	self.btn1 = [UIButton buttonWithType:UIButtonTypeCustom]; //Setup the button
	self.btn1.frame = CGRectMake(0, btnY, btnWidth, btnHeight); // Set the frame (size and position) of the button)
	[self.btn1 setImage:btnImageUnselect forState:UIControlStateNormal];
    [self.btn1 setImage:btnImageSelected forState:UIControlStateSelected];
	[self.btn1 setImage:btnImageSelected forState:UIControlStateSelected|UIControlStateHighlighted]; // Set the image for the selected state of the button
    [self.btn1 setImageEdgeInsets:UIEdgeInsetsMake(5, 20, 5, 20)];
    self.btn1.adjustsImageWhenHighlighted = NO;
	[self.btn1 setTag:0]; // Assign the button a "tag" so when our "click" event is called we know which button was pressed.
	[self.btn1 setSelected:true]; // Set this button as selected (we will select the others to false as we only want Tab 1 to be selected initially
    
	//  second tab
    btnImageUnselect = [UIImage imageNamed:@"TabbarMap"];
    btnImageSelected = [UIImage imageNamed:@"TabbarMap"];
	self.btn2 = [UIButton buttonWithType:UIButtonTypeCustom];
	self.btn2.frame = CGRectMake(btnWidth, btnY, btnWidth, btnHeight);
	[self.btn2 setImage:btnImageUnselect forState:UIControlStateNormal];
	[self.btn2 setImage:btnImageSelected forState:UIControlStateSelected];
    [self.btn2 setImage:btnImageSelected forState:UIControlStateSelected|UIControlStateHighlighted];
    [self.btn2 setImageEdgeInsets:UIEdgeInsetsMake(5, 20, 5, 20)];
    self.btn2.adjustsImageWhenHighlighted = NO;
	[self.btn2 setTag:1];
    
    //  third tab
    btnImageUnselect = [UIImage imageNamed:@"TabbarList"];
    btnImageSelected = [UIImage imageNamed:@"TabbarList"];
	self.btn3 = [UIButton buttonWithType:UIButtonTypeCustom];
	self.btn3.frame = CGRectMake(btnWidth * 2, btnY, btnWidth, btnHeight);
	[self.btn3 setImage:btnImageUnselect forState:UIControlStateNormal];
	[self.btn3 setImage:btnImageSelected forState:UIControlStateSelected];
    [self.btn3 setImage:btnImageSelected forState:UIControlStateSelected|UIControlStateHighlighted];
    [self.btn3 setImageEdgeInsets:UIEdgeInsetsMake(10, 22, 5, 22)];
    self.btn3.adjustsImageWhenHighlighted = NO;
	[self.btn3 setTag:2];
    
    //  forth tab
    btnImageUnselect = [UIImage imageNamed:@"TabbarSetting"];
    btnImageSelected = [UIImage imageNamed:@"TabbarSetting"];
	self.btn4 = [UIButton buttonWithType:UIButtonTypeCustom];
	self.btn4.frame = CGRectMake(btnWidth * 3, btnY, btnWidth, btnHeight);
	[self.btn4 setImage:btnImageUnselect forState:UIControlStateNormal];
	[self.btn4 setImage:btnImageSelected forState:UIControlStateSelected];
    [self.btn4 setImage:btnImageSelected forState:UIControlStateSelected|UIControlStateHighlighted];
    [self.btn4 setImageEdgeInsets:UIEdgeInsetsMake(8, 20, 5, 15)];
    self.btn4.adjustsImageWhenHighlighted = NO;
	[self.btn4 setTag:3];
    
    //  the loading of tabBar backgroundView
    _backgroundView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"TabbarBG"]];
    _backgroundView.frame = CGRectMake(0, btnY, 320, 50);
    [self.view addSubview:_backgroundView];
    
    //  selection mask
    _selectionMask = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"TabbarSelectedMask"]];
    
	// Add my new buttons to the view
	[self.view addSubview:self.btn1];
	[self.view addSubview:self.btn2];
    [self.view addSubview:self.btn3];
    [self.view addSubview:self.btn4];
    
    //  add selection mask
    [self.view addSubview:_selectionMask];
    [self adjustSelectionMaskForIndex:0];
    
	// Setup event handlers so that the buttonClicked method will respond to the touch up inside event.
	[self.btn1 addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchUpInside];
	[self.btn2 addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchUpInside];
    [self.btn3 addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchUpInside];
    [self.btn4 addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    //  delegate to the customTabDelegate that it should select current tab
//    [self performSelector:@selector(visibleTab) withObject:nil afterDelay:0.3];
}

- (void)visibleTab
{
    if ([customDelegate conformsToProtocol:@protocol(CustomTabDelegate)])
    {
        [customDelegate  selectCurrentTab];
    }
}

- (void)buttonClicked:(id)sender
{
	int tagNum = [sender tag];
    [customDelegate didselectTab:tagNum];
}

-(void) selectTab:(int)tabID {
    switch(tabID)
	{
		case 0:
            [self.btn2 setSelected:NO];
	        [_btn3 setSelected:NO];
            [_btn4 setSelected:NO];
			[self.btn1 setSelected:YES];
            
    		break;
		case 1:
			[self.btn1 setSelected:NO];
            [self.btn3 setSelected:NO];
            [self.btn4 setSelected:NO];
			[self.btn2 setSelected:YES];
            
            break;
            
        case 2:
            [self.btn1 setSelected:NO];
            [self.btn2 setSelected:NO];
            [self.btn4 setSelected:NO];
            [self.btn3 setSelected:YES];
            break;
        case 3:
            [self.btn1 setSelected:NO];
            [self.btn2 setSelected:NO];
            [self.btn3 setSelected:NO];
            [self.btn4 setSelected:YES];
    }
    
    //  adjust selection tab
    [self adjustSelectionMaskForIndex:tabID];
	
	self.selectedIndex = tabID;

}

-(void) hideNewTabBar {
    self.btn1.hidden = YES;
    self.btn2.hidden = YES;
    self.btn3.hidden = YES;
    self.btn4.hidden = YES;
    _selectionMask.hidden = YES;
    _backgroundView.hidden = YES;
}

-(void) ShowNewTabBar {
    self.btn1.hidden = NO;
    self.btn2.hidden = NO;
    self.btn3.hidden = NO;
    self.btn4.hidden = NO;
    _selectionMask.hidden = NO;
    _backgroundView.hidden = NO;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation
{
    // Return YES for supported orientations
    return (toInterfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
