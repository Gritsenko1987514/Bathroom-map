//
//  DimView.h
//  Labandme
//
//  Created by Xin Liang
//  Copyright 2012 Labandme.com
//

#import <UIKit/UIKit.h>

@interface DimView : UIView

@property (nonatomic, assign) BOOL isDim;

@end
