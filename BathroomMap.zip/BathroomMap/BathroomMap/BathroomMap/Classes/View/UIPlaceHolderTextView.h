//
//  UIPlaceHolderTextView.h
//  Laband.me
//
//  Created by Xin Liang on 1/15/13.
//  Copyright (c) 2013 Laband. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIPlaceHolderTextView : UITextView

@property (nonatomic, strong) UILabel *placeholderLabel;
@property (nonatomic, strong) NSString *placeholder;
@property (nonatomic, strong) UIColor *placeholderColor;

- (void)textChanged:(NSNotification *)notification;

@end
