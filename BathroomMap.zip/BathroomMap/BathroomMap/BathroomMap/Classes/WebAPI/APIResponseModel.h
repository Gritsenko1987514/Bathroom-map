//
//  APIResponseModel.h
//  Dash
//
//  Created by System Administrator on 4/29/12.
//  Copyright 2012 __DashTech__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface APIResponseModel : NSObject

@property (nonatomic, assign) int	status;
@property (nonatomic, strong) NSString *error;

+ (id)modelWithString:(NSString*)responseString;
- (id)initWithString:(NSString*)responseString;

@end
