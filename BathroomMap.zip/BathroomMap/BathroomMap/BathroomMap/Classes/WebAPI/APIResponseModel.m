//
//  APIResponseModel.m
//  SeekingArrangement
//
//  Created by System Administrator on 11/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "APIResponseModel.h"
#import "BMConstants.h"
#import "BMUtility.h"
#import "BMAppDelegate.h"
#import "BMAPI.h"
#import "JSON.h"

#define kStringStatus                   @"status"
#define kStringError                    @"error"

@implementation APIResponseModel

@synthesize status = _status;
@synthesize error = _error;

+ (id)modelWithString:(NSString*)responseString {
	return [[[APIResponseModel alloc] initWithString:responseString] autorelease];
}

- (id)initWithString:(NSString*)responseString {
	self = [super init];
	if (self) {
		id obj = [responseString JSONValue];
		
		if (!obj) return nil;
		if (![obj isKindOfClass:[NSDictionary class]]) return nil;
        
        id status = [obj objectForKey:kStringStatus];
        if (status && status != [NSNull null])
            _status = [status intValue];
        
        self.error = [obj objectForKey:kStringError];
	}
    
	return self;
} 

- (void)dealloc {
    [_error release];
    
	[super dealloc];
}

@end
