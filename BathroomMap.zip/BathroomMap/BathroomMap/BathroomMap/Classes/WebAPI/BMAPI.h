//
//  BMAPI.h
//  CardLust
//
//  Created by System Administrator on 7/30/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

#pragma mark - Constants

//  url
#define Server                  @"http://bathroommap.theblsgroup.net/api/bathroom"
#define DevServer               @"http://bathroommap.theblsgroup.net/api/bathroom"

//  API Call
#define Locations                 @"locations"
#define Feedbacks                 @"feedbacks"

//  string

//  parameter

//  notification
#define DidFinishSendMessage    @"DidFinishSendMessage"
#define DidFailSendMessage      @"DidFailSendMessage"

//  key
#define kKeyCommonResponse      @"CommonResponse"
#define kKeySpecificResponse    @"SpecificResponse"

#define kKeyRating              @"rating"
#define kKeyUser                @"user"
#define kKeyFeedback            @"feedback"
#define kKeyEmail               @"email"
#define kKeyPublish             @"publish"
#define kKeyLocationID          @"location_id"

@interface BMAPI : NSObject

#pragma mark - LifeCycle

+ (BMAPI *) sharedInstance;

+ (void) destroyInstance;

#pragma mark - WEB API

- (NSArray *)getLocations;

- (BOOL)submitFeedbackWithRating:(NSString*)rating user:(NSString*)username feedback:(NSString*)feedback email:(NSString*)emailAddress publish:(NSString*)publish locationid:(NSString*)locationID;

@end
