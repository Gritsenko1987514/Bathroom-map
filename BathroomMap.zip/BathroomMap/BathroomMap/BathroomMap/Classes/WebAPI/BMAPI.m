//
//  BMAPI.m
//  CardLust
//
//  Created by System Administrator on 7/30/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "BMAPI.h"
#import "BMConstants.h"
#import "ASIHTTPRequest.h"
#import "BMUtility.h"
#import "ASIFormDataRequest.h"
#import "BMAppDelegate.h"
#import "BMQueueHandler.h"
#import "APIResponseModel.h"
#import "BMLocation.h"
#import "JSON.h"

static BMAPI *instance;

#define ShortTimeout      10
#define LongTimeout       100

@implementation BMAPI

#pragma mark -
#pragma mark LifeCycle

+ (BMAPI *) sharedInstance {
	@synchronized ([BMAPI class])
	{
		if (!instance) {
			instance = [[BMAPI alloc] init];
		}
		return instance;
	}
}

+ (void) destroyInstance {
	@synchronized ([BMAPI class])
	{
        if (instance)
        {
            [instance release];
            instance = nil;            
        }
        
	}
}

- (id)init {
	self = [super init];
	
	if (self) {
		// customize this part
	}
	
	return self;
}

- (void) dealloc
{
    
	[super dealloc];
}

#pragma mark - ASIHTTP Delegate Methods


#pragma mark - WEB API

//  returun all locations from the server
//  else, return nil
- (NSArray *)getLocations
{
    NSString *urlString = [NSString stringWithFormat:@"%@/%@", DevServer, Locations];
#ifdef DEBUG
    NSLog(@"\n************ url of locations: %@ ***************\n", urlString);
#endif
    ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:[NSURL URLWithString:urlString]];
    
    //  send HTTPRequest
    [request startSynchronous];
    
    NSError *error = request.error;
    if (error)
    {
#ifdef DEBUG
        NSLog(
              @"\n========= Error ===========\nMessage:%@\nFile:%s\nLine:%d\n======== End ==========",
              error.description,
              __FILE__,
              __LINE__
              );
#endif
        return nil;
    }
    NSString *responseString;
    responseString = request.responseString;
#ifdef DEBUG
    NSLog(@"\n*************** responseString of locations: ***************\n %@\n", responseString);
#endif
    

    NSArray *responseArray = [responseString JSONValue];
    if (!responseArray)
        return nil;
    
    if (![responseArray isKindOfClass:[NSArray class]])
        return nil;
 
    NSMutableArray *locationArray = [[[NSMutableArray alloc] init] autorelease];
    
    for (NSDictionary *locationDictionary in responseArray) {
        BMLocation *location = [[[BMLocation alloc] initWithDictionary:locationDictionary] autorelease];
#ifdef DEBUG
        NSLog(@"location name: %@, lat: %f, long: %f, location address: %@", location.name, location.latitude, location.longitude, location.city);
#endif
        [locationArray addObject:location];
    }

    return locationArray;
}

- (BOOL)submitFeedbackWithRating:(NSString*)rating user:(NSString*)username feedback:(NSString*)feedback email:(NSString*)emailAddress publish:(NSString*)publish locationid:(NSString*)locationID
{
    NSString *urlString = [NSString stringWithFormat:@"%@/%@/%@", DevServer, Feedbacks, locationID];
#ifdef DEBUG
    NSLog(@"\n************ url of feedbacks: %@ ***************\n", urlString);
#endif
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:urlString]];
    
    [request setPostValue:rating forKey:kKeyRating];
    [request setPostValue:username forKey:kKeyUser];
    [request setPostValue:feedback forKey:kKeyFeedback];
    [request setPostValue:emailAddress forKey:kKeyEmail];
    [request setPostValue:publish forKey:kKeyPublish];
    [request setPostValue:locationID forKey:kKeyLocationID];
    
    [request setRequestMethod:@"POST"];
    
    //  send HTTPRequest
    [request startSynchronous];
    
    NSError *error = request.error;
    if (error)
    {
#ifdef DEBUG
        NSLog(
              @"\n========= Error ===========\nMessage:%@\nFile:%s\nLine:%d\n======== End ==========",
              error.description,
              __FILE__,
              __LINE__
              );
#endif
    }
    NSString *responseString;
    responseString = request.responseString;
#ifdef DEBUG
    NSLog(@"\n*************** responseString of feedbacks: ***************\n %@\n", responseString);
#endif
    
    NSMutableDictionary *newfeedback = [responseString JSONFragmentValue];
    if (!newfeedback)
        return FALSE;
    
    if (![newfeedback isKindOfClass:[NSDictionary class]])
        return FALSE;
    
    int status = request.responseStatusCode;
    if (status != 200)
        return FALSE;
    
    return TRUE;
}

#pragma mark - Utility

@end
