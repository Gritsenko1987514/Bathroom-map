//
//  BMQueueHandler.h
//  BLS Web Services
//
//  Created by XinLiang on 4/29/2012.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BMQueueHandler : NSObject
{

}

+ (NSOperationQueue *)requestQueue;
+ (NSOperationQueue *)imageDownloadQueue;
+ (void)destroyQueues;

@end
