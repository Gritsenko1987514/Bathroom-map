//
//  BMQueueHandler.m
//  BLS Web Services
//
//  Created by XinLiang on 4/29/2012.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "BMQueueHandler.h"

static NSOperationQueue *requestQueue;
static NSOperationQueue *imageDownloadQueue;

@implementation BMQueueHandler

+ (NSOperationQueue *)requestQueue
{
	@synchronized ([BMQueueHandler class])
	{
		if (!requestQueue)
			requestQueue = [[NSOperationQueue alloc] init];
		
		return requestQueue;
	}
}

+ (NSOperationQueue *)imageDownloadQueue
{
	@synchronized ([BMQueueHandler class])
	{
		if (!imageDownloadQueue)
			imageDownloadQueue = [[NSOperationQueue alloc] init];

		return imageDownloadQueue;
	}
}

+ (void)destroyQueues
{
	@synchronized ([BMQueueHandler class])
	{
		if (requestQueue)
		{
			[requestQueue release];
			requestQueue = nil;
		}
		if (imageDownloadQueue)
		{
			[imageDownloadQueue release];
			imageDownloadQueue = nil;
		}
	}
}

@end
